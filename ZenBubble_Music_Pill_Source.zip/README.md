# ZenBubble Music Pill

A minimal Android floating music pill. It listens for media notifications, reads the MediaSession token, and offers play/pause and next-track controls.

## Build
Open this project in Android Studio, or push it to the `main` branch of a GitHub repository. The included GitHub Actions workflow builds a debug APK.

## First run
1. Open ZenBubble Music Pill.
2. Grant display-over-other-apps permission.
3. Enable its notification access.
4. Start music in a supported music app.

The pill appears near the top of the screen when a media session notification is available. Some manufacturers may require allowing background activity/autostart.

## Notes
This is a starter implementation. It uses the system MediaSession notification token and does not download, store, or play music itself.
