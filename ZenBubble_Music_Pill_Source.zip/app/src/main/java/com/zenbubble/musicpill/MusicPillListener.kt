package com.zenbubble.musicpill

import android.app.Notification
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView

class MusicPillListener : NotificationListenerService() {
    private var wm: WindowManager? = null
    private var pill: LinearLayout? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var playButton: ImageButton? = null
    private var controller: MediaController? = null

    override fun onListenerConnected() {
        super.onListenerConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        activeNotifications?.forEach { inspect(it) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        inspect(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        val c = controller
        if (c != null && sbn.packageName == c.packageName) {
            controller = null
            removePill()
        }
    }

    private fun inspect(sbn: StatusBarNotification) {
        val notification = sbn.notification ?: return
        val token = notification.extras?.getParcelable<android.media.session.MediaSession.Token>(Notification.EXTRA_MEDIA_SESSION)
        if (token != null) {
            try { showFor(MediaController(this, token)) } catch (_: Exception) {}
        }
    }

    private fun showFor(tokenController: MediaController) {
        controller = tokenController
        if (!SettingsOverlay.allowed(this)) return
        if (pill == null) createPill()
        refresh()
    }

    private fun createPill() {
        val context = this
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(14, 8, 12, 8)
            background = GradientDrawable().apply {
                setColor(Color.rgb(10, 10, 14))
                cornerRadius = 100f
                setStroke(2, Color.rgb(95, 70, 170))
            }
        }
        val info = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        titleView = TextView(context).apply {
            text = "Now playing"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        artistView = TextView(context).apply {
            text = "Music"
            setTextColor(Color.LTGRAY)
            textSize = 10f
            maxLines = 1
        }
        info.addView(titleView)
        info.addView(artistView)
        playButton = ImageButton(context).apply {
            setImageResource(android.R.drawable.ic_media_pause)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.rgb(190, 160, 255))
            setOnClickListener { togglePlayback() }
            contentDescription = "Play or pause"
        }
        val next = ImageButton(context).apply {
            setImageResource(android.R.drawable.ic_media_next)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.WHITE)
            setOnClickListener { controller?.transportControls?.skipToNext() }
            contentDescription = "Next track"
        }
        box.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(playButton, LinearLayout.LayoutParams(42, 42))
        box.addView(next, LinearLayout.LayoutParams(42, 42))
        pill = box
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 32
        }
        try { wm?.addView(box, params) } catch (_: Exception) { pill = null }
    }

    private fun refresh() {
        val c = controller ?: return
        val metadata = c.metadata
        titleView?.text = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: c.packageName
        artistView?.text = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Now playing"
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playButton?.setImageResource(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
    }

    private fun togglePlayback() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
        else c.transportControls.play()
        pill?.postDelayed({ refresh() }, 250)
    }

    private fun removePill() {
        try { pill?.let { wm?.removeView(it) } } catch (_: Exception) {}
        pill = null
    }

    override fun onDestroy() {
        removePill()
        super.onDestroy()
    }
}
