package com.zenbubble.musicpill

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private fun listenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val cn = ComponentName(this, MusicPillListener::class.java)
        return enabled.split(":").any {
            val parsed = ComponentName.unflattenFromString(it)
            parsed?.packageName == cn.packageName && parsed.className == cn.className
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(12, 12, 18))
        }
        val title = TextView(this).apply {
            text = "ZenBubble Music Pill"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "A tiny floating music pill with album info and playback controls."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        val overlay = Button(this).apply {
            text = "Grant display-over-apps permission"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val access = Button(this).apply {
            text = "Enable music notification access"
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        val help = TextView(this).apply {
            text = "1. Allow display over other apps.\n2. Enable notification access.\n3. Play music in any app. The pill appears when a media notification is detected."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 22, 0, 0)
        }
        root.addView(title)
        root.addView(desc)
        root.addView(overlay)
        root.addView(access)
        root.addView(help)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // Notification-listener service is managed by Android after the user enables access.
    }
}
