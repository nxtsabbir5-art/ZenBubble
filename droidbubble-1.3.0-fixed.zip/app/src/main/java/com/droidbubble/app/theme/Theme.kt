package com.droidbubble.app.theme

import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ZenBubbleDark = darkColorScheme(
    primary = Color(0xFF9B5CFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF382064),
    onPrimaryContainer = Color(0xFFEBDDFF),
    secondary = Color(0xFF20C8FF),
    onSecondary = Color(0xFF00131D),
    secondaryContainer = Color(0xFF123A58),
    onSecondaryContainer = Color(0xFFD1F0FF),
    tertiary = Color(0xFFFF55C8),
    background = Color(0xFF070B18),
    onBackground = Color(0xFFF4F3FF),
    surface = Color(0xFF0D1427),
    onSurface = Color(0xFFF4F3FF),
    surfaceVariant = Color(0xFF171F36),
    onSurfaceVariant = Color(0xFFB7C0D8),
    surfaceContainerLowest = Color(0xFF060A15),
    surfaceContainerLow = Color(0xFF10182B),
    surfaceContainer = Color(0xFF141D33),
    surfaceContainerHigh = Color(0xFF1A2540),
    surfaceContainerHighest = Color(0xFF202C49),
    outline = Color(0xFF35415F),
    outlineVariant = Color(0xFF27334F),
    error = Color(0xFFFF647C),
    errorContainer = Color(0xFF49202D)
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun DroidbubbleTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialExpressiveTheme(
        colorScheme = ZenBubbleDark,
        typography = Typography,
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
