# ZenBubble Touch Region Fix v14

## Reported issue
After turning Island OFF and ON, the visible pill was only tappable near its lower edge.

## Root cause addressed
The overlay window was being resized between compact-height and full-screen bounds while Compose placed the pill using top offsets. This could leave the visual position and Android's touch coordinate space out of sync after a fresh attachment.

## Changes
- The overlay now keeps a stable full-screen WindowManager coordinate space while active.
- The existing IslandTouchManager is now connected to the Compose overlay.
- Main pill and secondary bubble report their actual Compose root bounds using onGloballyPositioned.
- Compact mode exposes only those reported rectangles as touchable, so the rest of the screen remains pass-through.
- Expanded mode uses the full window frame so outside-tap-to-collapse continues to work.
- OFF -> ON recreates the manager, clears old bounds, reattaches the listener, and reapplies current expanded/compact state.
- alwaysShowPill is treated as an interactive compact state.

## Validation
- ZIP structure and Kotlin brace/parenthesis balance checked.
- No on-device runtime test performed.
- Gradle compilation is not claimed as successful; run the GitHub Actions build before installing.
