package com.droidbubble.app

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.media.projection.MediaProjectionManager
import com.droidbubble.app.service.AudioPlaybackCaptureService
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.droidbubble.app.data.SettingsRepository
import com.droidbubble.app.service.IslandOverlayService
import com.droidbubble.app.theme.DroidbubbleTheme
import com.droidbubble.app.ui.main.MainScreen
import com.droidbubble.app.ui.main.MainScreenViewModel
import com.droidbubble.app.ui.main.PermissionHelper
import android.content.Intent
class MainActivity : ComponentActivity() {

    private val recordAudioPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) beginProjectionConsent()
        else Toast.makeText(this, "Microphone permission is required for playback capture", Toast.LENGTH_LONG).show()
    }

    private val audioCaptureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val captureIntent = Intent(this, AudioPlaybackCaptureService::class.java).apply {
                putExtra(AudioPlaybackCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(AudioPlaybackCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(captureIntent)
            else startService(captureIntent)
        }
    }

    private val viewModel by viewModels<MainScreenViewModel>(
        factoryProducer = {
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainScreenViewModel(SettingsRepository(applicationContext)) as T
                }
            }
        }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (intent?.action == ACTION_REQUEST_AUDIO_CAPTURE) requestAudioCapturePermission()

        viewModel.checkPermissions(this)
        if (PermissionHelper.isOverlayGranted(this)) {
            IslandOverlayService.start(this)
        }

        setContent {
            DroidbubbleTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(viewModel = viewModel)
                }
            }
        }
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == ACTION_REQUEST_AUDIO_CAPTURE) requestAudioCapturePermission()
    }

    private fun requestAudioCapturePermission() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            recordAudioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        } else {
            beginProjectionConsent()
        }
    }

    private fun beginProjectionConsent() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        audioCaptureLauncher.launch(manager.createScreenCaptureIntent())
    }

    companion object {
        const val ACTION_REQUEST_AUDIO_CAPTURE = "com.droidbubble.app.REQUEST_AUDIO_CAPTURE"
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkPermissions(this)
        if (PermissionHelper.isOverlayGranted(this)) {
            IslandOverlayService.start(this)
        }
    }
}
