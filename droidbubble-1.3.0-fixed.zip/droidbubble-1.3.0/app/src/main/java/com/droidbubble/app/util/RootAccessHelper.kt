package com.droidbubble.app.util

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

/**
 * Optional Magisk/SU integration.
 * Commands are limited to reversible SystemUI/status-bar settings.
 */
object RootAccessHelper {
    private const val TAG = "RootAccessHelper"
    private const val PREFS = "root_access_state"
    private const val KEY_OLD_BLACKLIST = "old_icon_blacklist"
    private const val KEY_OLD_POLICY = "old_policy_control"
    private const val KEY_SAVED = "root_settings_saved"
    private const val KEY_AUTO = "auto_hide_status_icons"
    private val executor = Executors.newSingleThreadExecutor()

    const val ICON_BLACKLIST =
        "wifi,cell,battery,clock,alarm_clock,bluetooth,volume,mute,vibrate,zen,dnd,location,gps,cast,hotspot,vpn,airplane"


    fun isAutoHideEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO, false)

    fun setAutoHideEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO, enabled).apply()
        if (!enabled) setAutomaticStatusBarMode(context, false)
    }

    /** Temporarily hides selected status icons while a notification is active or the island is expanded. */
    fun setAutomaticStatusBarMode(context: Context, active: Boolean) {
        executor.execute {
            if (active) {
                val saved = saveOriginalSettings(context)
                if (saved) runSu("settings put secure icon_blacklist '$ICON_BLACKLIST'")
            } else {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                if (prefs.getBoolean(KEY_SAVED, false)) {
                    val old = prefs.getString(KEY_OLD_BLACKLIST, null)
                    val command = if (old == null) "settings delete secure icon_blacklist"
                        else "settings put secure icon_blacklist ${shellQuote(old)}"
                    runSu(command)
                }
            }
        }
    }

    fun checkRoot(onResult: (Boolean) -> Unit) {
        executor.execute {
            val granted = runSu("id").let { it.first && it.second.contains("uid=0") }
            android.os.Handler(android.os.Looper.getMainLooper()).post { onResult(granted) }
        }
    }

    fun hideStatusBarIcons(context: Context, onResult: (Boolean, String) -> Unit) {
        executor.execute {
            val saved = saveOriginalSettings(context)
            val commands = listOf(
                "settings put secure icon_blacklist '$ICON_BLACKLIST'",
                "settings put global policy_control 'immersive.status=*'"
            )
            val ok = saved && commands.all { runSu(it).first }
            post { onResult(ok, if (ok) "Status bar icons hidden (where supported)." else "Root command failed. Check Magisk permission and device support.") }
        }
    }

    fun showStatusBarAgain(context: Context, onResult: (Boolean, String) -> Unit) {
        executor.execute {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val saved = prefs.getBoolean(KEY_SAVED, false)
            val blacklist = prefs.getString(KEY_OLD_BLACKLIST, null)
            val policy = prefs.getString(KEY_OLD_POLICY, null)
            val commands = mutableListOf<String>()
            if (saved) {
                commands += if (blacklist == null) "settings delete secure icon_blacklist"
                    else "settings put secure icon_blacklist ${shellQuote(blacklist)}"
                commands += if (policy == null) "settings delete global policy_control"
                    else "settings put global policy_control ${shellQuote(policy)}"
            } else {
                commands += "settings delete secure icon_blacklist"
                commands += "settings delete global policy_control"
            }
            val ok = commands.all { runSu(it).first }
            if (ok) prefs.edit().putBoolean(KEY_SAVED, false).apply()
            post { onResult(ok, if (ok) "Previous status bar settings restored." else "Could not restore settings. Check Root permission.") }
        }
    }

    private fun saveOriginalSettings(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_SAVED, false)) return true
        val a = runSu("settings get secure icon_blacklist")
        val b = runSu("settings get global policy_control")
        if (!a.first || !b.first) return false
        prefs.edit()
            .putString(KEY_OLD_BLACKLIST, a.second.trim().takeUnless { it == "null" })
            .putString(KEY_OLD_POLICY, b.second.trim().takeUnless { it == "null" })
            .putBoolean(KEY_SAVED, true)
            .apply()
        return true
    }

    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"

    private fun runSu(command: String): Pair<Boolean, String> {
        return try {
            val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val code = process.waitFor()
            (code == 0) to output
        } catch (t: Throwable) {
            Log.e(TAG, "su command failed: $command", t)
            false to (t.message ?: "Root unavailable")
        }
    }

    private fun post(block: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(block)
    }
}
