package com.droidbubble.app.util

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.util.concurrent.atomic.AtomicLong

/**
 * Optional Magisk/SU integration.
 * Commands are limited to reversible SystemUI/status-bar settings.
 */
object RootAccessHelper {
    private const val TAG = "RootAccessHelper"
    private const val PREFS = "root_access_state"
    private const val KEY_OLD_BLACKLIST = "old_icon_blacklist"
    private const val KEY_OLD_POLICY = "old_policy_control"
    private const val KEY_SAVED = "root_settings_saved"
    private const val KEY_AUTO = "auto_hide_status_icons"
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var rootProcess: Process? = null
    @Volatile private var rootWriter: BufferedWriter? = null
    @Volatile private var rootReader: BufferedReader? = null
    @Volatile private var rootVerified: Boolean? = null
    private val commandCounter = AtomicLong(0)
    private val rootLock = Any()

    const val ICON_BLACKLIST =
        "wifi,cell,battery,clock,alarm_clock,bluetooth,volume,mute,vibrate,zen,dnd,location,gps,cast,hotspot,vpn,airplane"


    fun isAutoHideEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO, false)

    fun setAutoHideEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO, enabled).apply()
        if (!enabled) {
            lastAutomaticMode = false
            executor.execute { restoreAutomaticBlacklist(context) }
        }
    }

    /** Temporarily hides selected status icons while a notification is active or the island is expanded. */
    @Volatile private var lastAutomaticMode: Boolean? = null
    fun setAutomaticStatusBarMode(context: Context, active: Boolean) {
        if (active && !isAutoHideEnabled(context)) return
        if (lastAutomaticMode == active) return
        lastAutomaticMode = active
        executor.execute {
            if (active) {
                val saved = saveOriginalSettings(context)
                if (saved) runSu("settings put secure icon_blacklist '$ICON_BLACKLIST'")
            } else {
                restoreAutomaticBlacklist(context)
            }
        }
    }

    private fun restoreAutomaticBlacklist(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_SAVED, false)) {
            val old = prefs.getString(KEY_OLD_BLACKLIST, null)
            val command = if (old == null) "settings delete secure icon_blacklist"
                else "settings put secure icon_blacklist ${shellQuote(old)}"
            runSu(command)
        }
    }

    fun checkRoot(onResult: (Boolean) -> Unit) {
        executor.execute {
            val cached = rootVerified
            val granted = cached ?: runSu("id").let { it.first && it.second.contains("uid=0") }
            android.os.Handler(android.os.Looper.getMainLooper()).post { onResult(granted) }
        }
    }

    fun hideStatusBarIcons(context: Context, onResult: (Boolean, String) -> Unit) {
        executor.execute {
            val saved = saveOriginalSettings(context)
            val commands = listOf(
                "settings put secure icon_blacklist '$ICON_BLACKLIST'",
                "settings put global policy_control 'immersive.status=*'"
            )
            val ok = saved && commands.all { runSu(it).first }
            post { onResult(ok, if (ok) "Status bar icons hidden (where supported)." else "Root command failed. Check Magisk permission and device support.") }
        }
    }

    fun showStatusBarAgain(context: Context, onResult: (Boolean, String) -> Unit) {
        executor.execute {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val saved = prefs.getBoolean(KEY_SAVED, false)
            val blacklist = prefs.getString(KEY_OLD_BLACKLIST, null)
            val policy = prefs.getString(KEY_OLD_POLICY, null)
            val commands = mutableListOf<String>()
            if (saved) {
                commands += if (blacklist == null) "settings delete secure icon_blacklist"
                    else "settings put secure icon_blacklist ${shellQuote(blacklist)}"
                commands += if (policy == null) "settings delete global policy_control"
                    else "settings put global policy_control ${shellQuote(policy)}"
            } else {
                commands += "settings delete secure icon_blacklist"
                commands += "settings delete global policy_control"
            }
            val ok = commands.all { runSu(it).first }
            if (ok) prefs.edit().putBoolean(KEY_SAVED, false).apply()
            post { onResult(ok, if (ok) "Previous status bar settings restored." else "Could not restore settings. Check Root permission.") }
        }
    }

    private fun saveOriginalSettings(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_SAVED, false)) return true
        val a = runSu("settings get secure icon_blacklist")
        val b = runSu("settings get global policy_control")
        if (!a.first || !b.first) return false
        prefs.edit()
            .putString(KEY_OLD_BLACKLIST, a.second.trim().takeUnless { it == "null" })
            .putString(KEY_OLD_POLICY, b.second.trim().takeUnless { it == "null" })
            .putBoolean(KEY_SAVED, true)
            .apply()
        return true
    }

    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"

    /** Reuses one authenticated `su` shell; commands are serialized on the single executor. */
    private fun runSu(command: String): Pair<Boolean, String> = synchronized(rootLock) {
        try {
            var process = rootProcess
            if (process == null || !process.isAlive) {
                closeRootSessionLocked()
                process = ProcessBuilder("su").redirectErrorStream(true).start()
                rootProcess = process
                rootWriter = BufferedWriter(OutputStreamWriter(process.outputStream))
                rootReader = BufferedReader(InputStreamReader(process.inputStream))
                rootVerified = null
            }
            val id = commandCounter.incrementAndGet()
            val marker = "__DROIDBUBBLE_DONE_${id}__"
            val writer = rootWriter ?: return@synchronized false to "Root shell unavailable"
            val reader = rootReader ?: return@synchronized false to "Root shell unavailable"
            writer.write(command)
            writer.newLine()
            writer.write("echo ${marker}:$?")
            writer.newLine()
            writer.flush()
            val output = StringBuilder()
            while (true) {
                val line = reader.readLine() ?: run {
                    closeRootSessionLocked()
                    return@synchronized false to "Root shell closed"
                }
                if (line.startsWith(marker + ":")) {
                    val code = line.substringAfter(':').trim().toIntOrNull() ?: 1
                    val result = output.toString().trim()
                    if (command == "id") rootVerified = code == 0 && result.contains("uid=0")
                    return@synchronized (code == 0) to result
                }
                output.append(line).append('\n')
            }
            @Suppress("UNREACHABLE_CODE")
            false to "Root command failed"
        } catch (t: Throwable) {
            Log.e(TAG, "su command failed", t)
            closeRootSessionLocked()
            false to (t.message ?: "Root unavailable")
        }
    }

    private fun closeRootSessionLocked() {
        try { rootWriter?.write("exit\n"); rootWriter?.flush() } catch (_: Throwable) {}
        try { rootProcess?.destroy() } catch (_: Throwable) {}
        rootWriter = null
        rootReader = null
        rootProcess = null
        rootVerified = null
    }

    private fun post(block: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(block)
    }
}
