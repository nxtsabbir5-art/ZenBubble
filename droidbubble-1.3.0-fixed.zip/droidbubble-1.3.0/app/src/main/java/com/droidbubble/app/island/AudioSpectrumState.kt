package com.droidbubble.app.island

import androidx.compose.runtime.mutableStateListOf

/** Shared real capture levels; empty/zero means no permitted audio is being captured. */
object AudioSpectrumState {
    val levels = mutableStateListOf(0f, 0f, 0f, 0f, 0f, 0f)
    fun update(values: List<Float>) {
        if (values.size != 6) return
        for (i in 0 until 6) levels[i] = values[i].coerceIn(0f, 1f)
    }
    fun clear() { for (i in 0 until 6) levels[i] = 0f }
    val active: Boolean get() = levels.any { it > 0.025f }
}
