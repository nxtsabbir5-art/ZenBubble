# Frosted Glass v7 changes

- Added independent `Island Frosted Glass` and `Notification Frosted Glass` switches.
- Island switch controls the existing glass fallback across Island capsule/card content (media, weather, network, battery/widget and other Island panels where the shared Island glass styling is used).
- Notification switch independently applies a translucent slate glass tint and subtle white glass highlight to incoming notification/message cards.
- Both switches share the glass-strength slider. The fallback uses translucent Compose surfaces and highlights; it does not claim to blur pixels from other apps on devices without Android cross-window blur support.
- Existing Compose spring/transition animations are retained; the fallback avoids continuous full-screen bitmap processing to help keep the overlay responsive.

Build status: not verified. Gradle 9.1.0 distribution could not be downloaded in this environment because `services.gradle.org` was unreachable.
