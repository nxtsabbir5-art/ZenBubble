package com.droidbubble.app.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val ZenDarkColorScheme = darkColorScheme(
  primary = ZenPurple,
  onPrimary = Color.White,
  primaryContainer = Color(0xFF2E2570),
  onPrimaryContainer = Color(0xFFE6DFFF),
  secondary = Color(0xFFB69CFF),
  onSecondary = Color(0xFF1B1245),
  secondaryContainer = Color(0xFF262C4A), // slider inactive track
  onSecondaryContainer = Color(0xFFDCE0FF),
  tertiary = ZenMagenta,
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFF4A1A5C),
  onTertiaryContainer = Color(0xFFFFD6FF),
  background = ZenNavy1,
  onBackground = Color(0xFFEDEFFF),
  surface = Color(0xFF0F1428),
  onSurface = Color(0xFFEDEFFF),
  surfaceVariant = Color(0xFF1B2244),
  onSurfaceVariant = Color(0xFF9AA3C7),
  surfaceTint = ZenPurple,
  outline = Color(0xFF3A4270),
  outlineVariant = ZenBorderDark,
  error = Color(0xFFFF6B7A),
  onError = Color(0xFF3B0A12),
  errorContainer = Color(0xFF4A1F2B),
  onErrorContainer = Color(0xFFFFD9DD),
  surfaceContainerLowest = ZenNavy0,
  surfaceContainerLow = ZenCardDark,
  surfaceContainer = Color(0xFF161C3A),
  surfaceContainerHigh = ZenCardDarkHigh,
  surfaceContainerHighest = ZenCardDarkHighest,
)

private val ZenLightColorScheme = lightColorScheme(
  primary = ZenPurpleDeep,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE4DCFF),
  onPrimaryContainer = Color(0xFF1E1259),
  secondary = Color(0xFF6D55C9),
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFDDD7F7),
  onSecondaryContainer = Color(0xFF1E1259),
  tertiary = Color(0xFFB02BC9),
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFFFAD6FF),
  onTertiaryContainer = Color(0xFF3B0048),
  background = ZenLightBg0,
  onBackground = Color(0xFF14172B),
  surface = Color(0xFFFBFAFF),
  onSurface = Color(0xFF14172B),
  surfaceVariant = Color(0xFFE8E3FF),
  onSurfaceVariant = Color(0xFF5A6085),
  surfaceTint = ZenPurpleDeep,
  outline = Color(0xFF8A8FB5),
  outlineVariant = ZenBorderLight,
  error = Color(0xFFD93A4C),
  onError = Color.White,
  errorContainer = Color(0xFFFFDADD),
  onErrorContainer = Color(0xFF410009),
  surfaceContainerLowest = Color.White,
  surfaceContainerLow = ZenCardLight,
  surfaceContainer = Color(0xFFF6F3FF),
  surfaceContainerHigh = ZenCardLightHigh,
  surfaceContainerHighest = ZenCardLightHighest,
)

private val ZenShapes = Shapes(
  extraSmall = RoundedCornerShape(8.dp),
  small = RoundedCornerShape(12.dp),
  medium = RoundedCornerShape(16.dp),
  large = RoundedCornerShape(22.dp),
  extraLarge = RoundedCornerShape(28.dp),
)

/** Vertical background gradient used behind every screen (navy → purple tint). */
@Composable
fun zenBackgroundBrush(): Brush {
  val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
  return if (isDark) {
    Brush.verticalGradient(listOf(ZenNavy1, ZenNavy2, ZenNavy3))
  } else {
    Brush.verticalGradient(listOf(ZenLightBg0, ZenLightBg1))
  }
}

/** Brand accent gradient (purple → violet → magenta). */
val ZenAccentBrush: Brush
  get() = Brush.linearGradient(listOf(Color(0xFF3D8BFF), ZenPurple, ZenMagenta))

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun DroidbubbleTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Set to true to use Material You wallpaper colors instead of the iBubble palette (Android 12+)
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> ZenDarkColorScheme
      else -> ZenLightColorScheme
    }

  MaterialExpressiveTheme(
    colorScheme = colorScheme,
    typography = Typography,
    shapes = ZenShapes,
    motionScheme = MotionScheme.expressive(),
    content = content
  )
}
