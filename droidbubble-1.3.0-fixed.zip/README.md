# ZenPlayer — Android Studio Source

Offline music player starter project with a dark frosted-glass inspired UI.

## Included
- Local audio library scanning through MediaStore
- Search by title or artist
- Media3 ExoPlayer playback
- Real Media3 `MediaSessionService` for background playback and Android media controls
- Play/pause/previous/next/seek controls
- ZenPlayer launcher icon (adaptive icon on Android 8.0+)
- `android:allowAudioPlaybackCapture="true"` opt-in for eligible playback capture

## Build
- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.9 / Android Gradle Plugin 8.7.3
- GitHub Actions workflow is included at `.github/workflows/android.yml`.
- The workflow caches Gradle dependencies and Android SDK components to reduce repeat downloads. The first run may still need to download uncached components.

## Playback capture note
This app opts in to Android playback capture through its manifest. It does not itself start MediaProjection or record system audio. A capture app such as ZenBubble still needs the user's MediaProjection consent and must use AudioPlaybackCapture correctly. DRM, app policy, audio usage, Android restrictions, and OEM behavior can prevent capture.

## Notes
MediaSessionService publishes the active session to Android system media controls and compatible apps. Album artwork is not currently extracted from the local audio files; metadata currently includes title and artist.
