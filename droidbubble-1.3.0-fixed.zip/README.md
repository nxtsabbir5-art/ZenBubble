# ZenPlayer — Android Studio Source

A minimal offline music player starter project with a frosted-glass inspired dark UI.

## Features
- Scans local audio using Android MediaStore
- Search by title or artist
- Playback with AndroidX Media3 ExoPlayer
- Previous / play-pause / next / seek controls
- Requests runtime audio-library permission
- Declares `android:allowAudioPlaybackCapture="true"` so Android playback capture is not explicitly disabled by this app

## Build
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Use JDK 17.
3. Let Gradle sync and download dependencies.
4. Run the `app` configuration on an Android device.

## Audio capture note
This app opts in to Android playback capture through the application manifest. It does **not** itself start MediaProjection or record system audio. Another app (such as ZenBubble) still needs the user's MediaProjection consent, must use AudioPlaybackCapture correctly, and can capture only audio that Android and the source app permit. DRM, device policy, audio usage, user/profile boundaries, and OEM restrictions can prevent capture.

## Scope / limitations
This is a functional starter source, not a fully polished commercial player. Album-art extraction, playlists, folder browsing, queue management, equalizer, sleep timer, and a dedicated MediaSessionService implementation can be added in a next iteration. Test on-device before daily use.
