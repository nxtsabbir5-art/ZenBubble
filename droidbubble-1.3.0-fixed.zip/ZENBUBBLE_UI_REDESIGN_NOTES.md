# ZenBubble UI Redesign — based on original Droidbubble 1.3.0 source

This update starts from the user-uploaded `droidbubble-1.3.0-fixed.zip`, not from the previous v11 archive.

## UI changes
- Replaced the app theme with a fixed premium dark navy palette and violet/cyan accents. Dynamic Android wallpaper colors are disabled so the interface remains visually consistent.
- Added a ZenBubble branded home header with gradient Z mark and live service status.
- Added shortcut cards for Island Style, Position & Size, Animations, and More Settings.
- Added a live Island preview card to Position & Size, reflecting width, height and corner radius.
- Added six tappable Island shape presets (Default, Round, Capsule, Wide, Minimal, iOS Style). These presets update the existing width and corner-radius settings.
- Renamed the dimensions and appearance page titles to match the reference.

## Compatibility
- Existing service, settings, permissions, and Island features from the original uploaded source are retained.
- No prior v9/v10 experimental overlay changes were carried forward.

## Build verification
The project XML files parse and the source ZIP passes its archive integrity test. Kotlin/Gradle compilation could not be run because the wrapper attempted to download Gradle 9.1.0 and the environment could not resolve `services.gradle.org`. Please run `./gradlew :app:compileDebugKotlin` or the GitHub Actions workflow before installing.
