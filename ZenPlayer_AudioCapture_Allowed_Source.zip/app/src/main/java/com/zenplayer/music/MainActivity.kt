package com.zenplayer.music

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor
import kotlinx.coroutines.delay

 data class Song(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private val controllerState = mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZenPlayerApp(controllerState.value) }
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controllerState.value = controllerFuture?.get()
            } catch (_: Exception) {
                controllerState.value = null
            }
        }, Executor { command -> runOnUiThread(command) })
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controllerState.value = null
        super.onDestroy()
    }
}

@Composable
fun ZenPlayerApp(player: MediaController?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var selected by remember { mutableStateOf<Song?>(null) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var query by remember { mutableStateOf("") }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) }

    fun loadSongs() {
        val list = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        context.contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c: Cursor ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                list += Song(id, c.getString(titleCol) ?: "Unknown title", c.getString(artistCol) ?: "Unknown artist",
                    ContentUris.withAppendedId(collection, id), c.getLong(durationCol))
            }
        }
        songs = list
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        if (ok) loadSongs()
    }
    LaunchedEffect(Unit) {
        if (granted) loadSongs() else launcher.launch(permission)
    }
    LaunchedEffect(player) {
        while (true) {
            playing = player?.isPlaying == true
            position = player?.currentPosition?.coerceAtLeast(0) ?: 0L
            duration = (player?.duration?.takeIf { it > 0 } ?: 1L)
            val current = player?.currentMediaItem
            if (current != null) {
                val currentUri = current.localConfiguration?.uri
                val librarySong = songs.firstOrNull { it.uri == currentUri }
                val meta = current.mediaMetadata
                val nowPlaying = librarySong ?: Song(-1L, meta.title?.toString() ?: "Now playing", meta.artist?.toString() ?: "Unknown artist", currentUri ?: Uri.EMPTY, duration)
                if (selected?.id != nowPlaying.id || selected?.title != nowPlaying.title) selected = nowPlaying
            } else if (player?.mediaItemCount == 0) {
                selected = null
            }
            delay(250)
        }
    }

    val filtered = songs.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    val bg = Color(0xFF080B13)
    val glass = Color(0x26FFFFFF)
    val accent = Color(0xFF9C8CFF)

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = bg, surface = Color(0xFF151927))) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF202746), bg, Color(0xFF101827))))) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ZENPLAYER", color = Color.White, fontSize = 12.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
                        Text("Your music, offline.", color = Color(0xFFB7B9CC), fontSize = 13.sp)
                    }
                    Icon(Icons.Default.GraphicEq, null, tint = accent, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.height(24.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search your library", color = Color(0xFF999DB1)) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Color(0xFFB9BBD0)) },
                    singleLine = true, shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent, unfocusedBorderColor = Color(0x44FFFFFF),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = accent
                    )
                )
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Your Library", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("${filtered.size} TRACKS", color = Color(0xFF9FA4BA), fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
                Spacer(Modifier.height(10.dp))
                if (!granted) {
                    Text("Allow audio permission to scan offline songs.", color = Color.White)
                    Button(onClick = { launcher.launch(permission) }) { Text("Allow access") }
                } else if (filtered.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(if (songs.isEmpty()) "No music found on this device" else "No matching tracks", color = Color(0xFF9FA4BA))
                    }
                } else {
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(filtered, key = { it.id }) { song ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(glass).clickable {
                                    selected = song
                                    val mediaItems = filtered.map { s ->
                                        MediaItem.Builder().setUri(s.uri).setMediaMetadata(
                                            MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).build()
                                        ).build()
                                    }
                                    val index = filtered.indexOf(song)
                                    player?.setMediaItems(mediaItems, index, 0L)
                                    player?.prepare()
                                    player?.play()
                                }.padding(12.dp), verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(
                                    Brush.linearGradient(listOf(Color(0xFF6559A9), Color(0xFF25304A)))
                                ), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.MusicNote, null, tint = Color.White)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(song.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(song.artist, color = Color(0xFFB0B4C8), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(formatTime(song.duration), color = Color(0xFF9FA4BA), fontSize = 11.sp)
                            }
                        }
                    }
                }
                selected?.let { song ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(
                        Brush.linearGradient(listOf(Color(0x553F4770), Color(0x332FFFFFF)))
                    ).padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("NOW PLAYING", color = accent, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = Color(0xFFB0B4C8), fontSize = 12.sp)
                            }
                            Icon(Icons.Default.GraphicEq, null, tint = accent, modifier = Modifier.size(25.dp))
                        }
                        Slider(value = position.toFloat().coerceIn(0f, duration.toFloat()), onValueChange = { player?.seekTo(it.toLong()) },
                            valueRange = 0f..duration.toFloat(), colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(formatTime(position), color = Color(0xFF9FA4BA), fontSize = 10.sp)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { player?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                            IconButton(onClick = { if (player?.isPlaying == true) player.pause() else player?.play() },
                                modifier = Modifier.size(52.dp).clip(CircleShape).background(accent)) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF101322), modifier = Modifier.size(30.dp))
                            }
                            IconButton(onClick = { player?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                            Spacer(Modifier.width(8.dp))
                            Text(formatTime(duration), color = Color(0xFF9FA4BA), fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}
