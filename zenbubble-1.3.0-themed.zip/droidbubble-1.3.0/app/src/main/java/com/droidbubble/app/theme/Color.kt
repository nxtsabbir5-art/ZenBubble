package com.droidbubble.app.theme

import androidx.compose.ui.graphics.Color

// ───────────────────────── ZenBubble palette ─────────────────────────

// Brand accents (purple → violet → magenta, like the "Z" logo)
val ZenPurple = Color(0xFF7B61FF)
val ZenPurpleDeep = Color(0xFF5B3FE0)
val ZenViolet = Color(0xFFA855F7)
val ZenMagenta = Color(0xFFE040FB)
val ZenPink = Color(0xFFFF4FA3)
val ZenBlue = Color(0xFF3B82F6)
val ZenGreen = Color(0xFF22C55E)

// Dark surfaces (deep navy)
val ZenNavy0 = Color(0xFF0A0E1C)
val ZenNavy1 = Color(0xFF0B1020)
val ZenNavy2 = Color(0xFF111633)
val ZenNavy3 = Color(0xFF1A1244) // purple-tinted bottom of the gradient
val ZenCardDark = Color(0xFF121833)
val ZenCardDarkHigh = Color(0xFF1B2244)
val ZenCardDarkHighest = Color(0xFF232B55)
val ZenBorderDark = Color(0xFF272E52)

// Light surfaces
val ZenLightBg0 = Color(0xFFF6F5FF)
val ZenLightBg1 = Color(0xFFECE8FF)
val ZenCardLight = Color(0xFFFFFFFF)
val ZenCardLightHigh = Color(0xFFF1EEFF)
val ZenCardLightHighest = Color(0xFFE8E3FF)
val ZenBorderLight = Color(0xFFDAD3FA)

// Legacy names (kept so nothing else in the project breaks)
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
