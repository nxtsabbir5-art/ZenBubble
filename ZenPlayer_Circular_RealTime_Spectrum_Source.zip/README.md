# ZenPlayer — Music + Video Edition

## Features
- Offline music library scanning with search and Favorites
- Local video library scanning and in-app video playback
- Media3 ExoPlayer + MediaSessionService for background audio playback and system media controls
- Play/pause, seek, previous/next, shuffle and repeat for music
- Video playback controls and expanded/full-screen-style player dialog
- Six accent color presets
- Choose a gallery photo as the app background, adjust blur (0–40 dp), or remove it
- UI preferences (accent, background image, blur and favorites) are saved locally
- Android Photo Picker for background image selection
- ZenBubble audio capture compatibility retained:
  - `android:allowAudioPlaybackCapture="true"`
  - `USAGE_MEDIA` + `ALLOW_CAPTURE_BY_ALL`

## Build
- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Android Gradle Plugin 8.7.3 / Kotlin 2.0.21
- GitHub Actions workflow: `.github/workflows/android.yml`

## Important capture note
ZenPlayer opts in to Android playback capture. ZenBubble still needs to request and receive the user's MediaProjection consent. DRM, Android policy, source-app capture restrictions, and OEM behavior can still prevent capture.

## Notes
This is an offline local-media player. The project does not include online streaming, lyrics fetching, cloud sync, or a remote catalog. Verify the APK on the target phone after building.
