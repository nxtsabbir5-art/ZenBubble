package com.zenplayer.music

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.BitmapFactory
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import java.util.concurrent.Executor

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

private val palettes = listOf(
    "Violet" to 0xFF9B83FF, "Ocean" to 0xFF45C7D9, "Rose" to 0xFFFF729A,
    "Emerald" to 0xFF52D6A0, "Amber" to 0xFFFFB454, "Ice" to 0xFF8DBBFF
)

class MainActivity : ComponentActivity() {
    private val controllerState = mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZenPlayerApp(controllerState.value) }
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { controllerState.value = controllerFuture?.get() } catch (_: Exception) { controllerState.value = null }
        }, Executor { it.runOnUiThreadCompat(this) })
    }
    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controllerState.value = null
        super.onDestroy()
    }
}
private fun Runnable.runOnUiThreadCompat(activity: ComponentActivity) = activity.runOnUiThread(this)


@Composable
fun CircularSpectrum(player: MediaController?, accent: Color, modifier: Modifier = Modifier) {
    var levels by remember { mutableStateOf(List(48) { 0.08f }) }
    DisposableEffect(player) {
        var visualizer: Visualizer? = null
        try {
            val sessionId = player?.audioSessionId ?: 0
            if (sessionId > 0) {
                visualizer = Visualizer(sessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer, data: ByteArray, samplingRate: Int) {
                            val next = List(48) { i ->
                                val index = (i * data.size / 48).coerceIn(data.indices)
                                ((data[index].toInt() and 0xff) / 255f).coerceIn(0.04f, 1f)
                            }
                            levels = next
                        }
                        override fun onFftDataCapture(v: Visualizer, data: ByteArray, samplingRate: Int) {
                            val next = List(48) { i ->
                                val index = (2 + i * 2).coerceIn(2, data.lastIndex - 1)
                                val real = data[index].toInt()
                                val imag = data[index + 1].toInt()
                                (kotlin.math.sqrt((real * real + imag * imag).toDouble()).toFloat() / 90f).coerceIn(0.05f, 1f)
                            }
                            levels = next
                        }
                    }, Visualizer.getMaxCaptureRate() / 2, false, true)
                    enabled = true
                }
            }
        } catch (_: Exception) { visualizer = null }
        onDispose {
            try { visualizer?.enabled = false; visualizer?.release() } catch (_: Exception) {}
        }
    }
    val animated = levels
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val base = size.minDimension * 0.34f
            val maxExtra = size.minDimension * 0.13f
            val count = 48
            for (i in 0 until count) {
                val angle = (i * 360f / count - 90f) * Math.PI.toFloat() / 180f
                val level = animated[i].coerceIn(0.04f, 1f)
                val inner = base + size.minDimension * 0.025f
                val outer = inner + maxExtra * level
                val start = Offset(center.x + kotlin.math.cos(angle) * inner, center.y + kotlin.math.sin(angle) * inner)
                val end = Offset(center.x + kotlin.math.cos(angle) * outer, center.y + kotlin.math.sin(angle) * outer)
                drawLine(accent.copy(alpha = 0.45f + level * 0.55f), start, end, strokeWidth = size.minDimension * 0.012f, cap = StrokeCap.Round)
            }
            drawCircle(accent.copy(alpha = 0.16f), radius = base, center = center, style = Stroke(width = size.minDimension * 0.008f))
        }
        Box(Modifier.fillMaxSize(0.57f).clip(CircleShape).background(Color(0xFF252A3B)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Album, null, tint = Color.White.copy(alpha = 0.82f), modifier = Modifier.fillMaxSize(0.48f))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZenPlayerApp(player: MediaController?) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("zenplayer_ui", 0) }
    var tab by remember { mutableStateOf("Music") }
    var songs by remember { mutableStateOf<List<Track>>(emptyList()) }
    var videos by remember { mutableStateOf<List<Track>>(emptyList()) }
    var selected by remember { mutableStateOf<Track?>(null) }
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var shuffle by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showSettings by remember { mutableStateOf(false) }
    var accentIndex by remember { mutableIntStateOf(prefs.getInt("accent", 0).coerceIn(palettes.indices)) }
    var bgUri by remember { mutableStateOf(prefs.getString("bg_uri", null)?.let(Uri::parse)) }
    var blurAmount by remember { mutableFloatStateOf(prefs.getFloat("blur", 18f)) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var videoMode by remember { mutableStateOf(false) }
    var fullScreenVideo by remember { mutableStateOf(false) }
    val accent = Color(palettes[accentIndex].second)
    val dark = Color(0xFF090B13)
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val videoPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
    var audioGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED) }
    var videoGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, videoPermission) == PackageManager.PERMISSION_GRANTED) }

    fun scanAudio() {
        val result = mutableListOf<Track>()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        context.contentResolver.query(uri, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val title = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val dur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) { val n=c.getLong(id); result += Track(n,c.getString(title) ?: "Unknown",c.getString(artist) ?: "Unknown artist",ContentUris.withAppendedId(uri,n),c.getLong(dur)) }
        }
        songs = result
    }
    fun scanVideos() {
        val result = mutableListOf<Track>()
        val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION)
        context.contentResolver.query(uri, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
            val id=c.getColumnIndexOrThrow(MediaStore.Video.Media._ID); val title=c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE); val dur=c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while(c.moveToNext()){ val n=c.getLong(id); result += Track(n,c.getString(title) ?: "Video", "Video", ContentUris.withAppendedId(uri,n), c.getLong(dur)) }
        }
        videos = result
    }
    val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        audioGranted = result[audioPermission] == true || ContextCompat.checkSelfPermission(context,audioPermission)==PackageManager.PERMISSION_GRANTED
        videoGranted = result[videoPermission] == true || ContextCompat.checkSelfPermission(context,videoPermission)==PackageManager.PERMISSION_GRANTED
        if(audioGranted) scanAudio(); if(videoGranted) scanVideos()
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if(uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            bgUri = uri; prefs.edit().putString("bg_uri", uri.toString()).apply()
        }
    }
    LaunchedEffect(Unit) {
        if(audioGranted) scanAudio()
        if(videoGranted) scanVideos()
        if(!audioGranted || !videoGranted) permissions.launch(arrayOf(audioPermission,videoPermission).distinct().toTypedArray())
    }
    LaunchedEffect(player) {
        while(true) {
            playing = player?.isPlaying == true
            position = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
            duration = (player?.duration?.takeIf { it > 0 } ?: 1L)
            val current = player?.currentMediaItem
            if(current != null) {
                val uri=current.localConfiguration?.uri
                val match=(songs+videos).firstOrNull { it.uri==uri }
                val meta=current.mediaMetadata
                selected = match ?: Track(-1,meta.title?.toString() ?: "Now Playing",meta.artist?.toString() ?: "",uri ?: Uri.EMPTY,duration)
            }
            delay(250)
        }
    }
    val list = (if(tab=="Videos") videos else if(tab=="Favorites") songs.filter { favorites.contains(it.id.toString()) } else songs)
    val filtered = list.filter { it.title.contains(query,true) || it.artist.contains(query,true) }
    val backgroundBitmap = remember(bgUri) {
        try { bgUri?.let { context.contentResolver.openInputStream(it)?.use { input -> BitmapFactory.decodeStream(input)?.asImageBitmap() } } } catch (_:Exception) { null }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary=accent, background=dark, surface=Color(0xFF171A28))) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1C2340),dark,Color(0xFF111827))))) {
            if(backgroundBitmap != null) {
                Image(backgroundBitmap, null, Modifier.fillMaxSize().blur(blurAmount.dp), contentScale=ContentScale.Crop, alpha=0.42f)
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=0.38f)))
            }
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal=18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top=14.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ZENPLAYER",color=Color.White,fontSize=12.sp,letterSpacing=4.sp,fontWeight=FontWeight.Bold)
                        Text("Music • Video • Your style",color=Color(0xFFB8BDD0),fontSize=12.sp)
                    }
                    IconButton(onClick={showSettings=true}) { Icon(Icons.Default.Palette,null,tint=accent) }
                    Icon(Icons.Default.GraphicEq,null,tint=accent,modifier=Modifier.size(26.dp))
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha=.08f)).padding(4.dp)) {
                    listOf("Music","Videos","Favorites").forEach { name ->
                        val active=tab==name
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if(active) accent else Color.Transparent).clickable { tab=name; query="" }.padding(vertical=11.dp),contentAlignment=Alignment.Center) {
                            Text(name,color=if(active) Color(0xFF111321) else Color.White,fontWeight=FontWeight.SemiBold,fontSize=13.sp)
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),placeholder={Text("Search ${tab.lowercase()}")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(18.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=accent,unfocusedBorderColor=Color.White.copy(alpha=.15f),focusedTextColor=Color.White,unfocusedTextColor=Color.White,cursorColor=accent))
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text(if(tab=="Videos") "Your Videos" else if(tab=="Favorites") "Liked Tracks" else "Your Library",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.weight(1f)); Text("${filtered.size} ITEMS",color=Color(0xFFADB3C6),fontSize=10.sp,letterSpacing=1.sp)
                }
                Spacer(Modifier.height(10.dp))
                if(filtered.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            Icon(if(tab=="Videos") Icons.Default.VideoLibrary else Icons.Default.LibraryMusic,null,tint=accent,modifier=Modifier.size(42.dp))
                            Spacer(Modifier.height(10.dp))
                            Text(if(tab=="Videos" && !videoGranted) "Allow video access to scan videos" else if(tab=="Music" && !audioGranted) "Allow audio access to scan music" else "Nothing found here yet",color=Color.White)
                            Text("Your files stay on this device",color=Color(0xFF9FA6BA),fontSize=12.sp)
                            TextButton(onClick={permissions.launch(arrayOf(audioPermission,videoPermission).distinct().toTypedArray())}) { Text("Grant media access",color=accent) }
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(bottom=12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        items(filtered,key={ "${tab}_${it.id}" }) { item ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha=.09f)).clickable {
                                selected=item; videoMode=tab=="Videos"
                                val queue=filtered.map { t -> MediaItem.Builder().setUri(t.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).build()).build() }
                                player?.setMediaItems(queue,filtered.indexOf(item),0L); player?.prepare(); player?.play()
                            }.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(accent.copy(alpha=.8f),Color(0xFF26304A)))),contentAlignment=Alignment.Center) {
                                    Icon(if(tab=="Videos") Icons.Default.PlayCircle else Icons.Default.MusicNote,null,tint=Color.White,modifier=Modifier.size(25.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.title,color=Color.White,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                                    Text(item.artist.ifBlank { "Unknown artist" },color=Color(0xFFB3B8CA),fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                }
                                if(tab!="Videos") IconButton(onClick={
                                    val set=favorites.toMutableSet()
                                    if(set.contains(item.id.toString())) set.remove(item.id.toString()) else set.add(item.id.toString())
                                    favorites=set; prefs.edit().putStringSet("favorites",set).apply()
                                }) { Icon(if(favorites.contains(item.id.toString())) Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(favorites.contains(item.id.toString())) accent else Color.LightGray) }
                                Text(formatTime(item.duration),color=Color(0xFFADB3C6),fontSize=11.sp)
                            }
                        }
                    }
                }
                if(selected!=null && player!=null) {
                    val currentVideo=videoMode
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xCC151927)).padding(14.dp)) {
                        if(!currentVideo) {
                            CircularSpectrum(player, accent, Modifier.fillMaxWidth().height(230.dp).padding(vertical = 4.dp))
                        }
                        if(currentVideo) {
                            AndroidView(factory={ ctx -> PlayerView(ctx).apply { useController=true; this.player=player; resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT } },
                                modifier=Modifier.fillMaxWidth().height(185.dp), update={ it.player=player })
                            TextButton(onClick={ fullScreenVideo=true }, modifier=Modifier.align(Alignment.End)) { Icon(Icons.Default.Fullscreen,null,tint=accent); Spacer(Modifier.width(4.dp)); Text("Full screen",color=accent) }
                        }
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if(currentVideo) "NOW PLAYING • VIDEO" else "NOW PLAYING",color=accent,fontSize=9.sp,letterSpacing=1.8.sp,fontWeight=FontWeight.Bold)
                                Text(selected?.title ?: "",color=Color.White,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                                Text(selected?.artist ?: "",color=Color(0xFFB5BBD0),fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                            }
                            if(!currentVideo) Icon(Icons.Default.GraphicEq,null,tint=accent,modifier=Modifier.size(24.dp))
                        }
                        Slider(value=position.toFloat().coerceIn(0f,duration.toFloat()),onValueChange={player.seekTo(it.toLong())},valueRange=0f..duration.toFloat(),colors=SliderDefaults.colors(thumbColor=accent,activeTrackColor=accent))
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text(formatTime(position),color=Color(0xFFADB3C6),fontSize=10.sp)
                            Spacer(Modifier.weight(1f))
                            if(!currentVideo) IconButton(onClick={shuffle=!shuffle;player.shuffleModeEnabled=shuffle}) { Icon(Icons.Default.Shuffle,null,tint=if(shuffle) accent else Color.White) }
                            IconButton(onClick={player.seekToPreviousMediaItem()}) { Icon(Icons.Default.SkipPrevious,null,tint=Color.White) }
                            IconButton(onClick={if(player.isPlaying) player.pause() else player.play()},modifier=Modifier.size(48.dp).clip(CircleShape).background(accent)) { Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=Color(0xFF111321),modifier=Modifier.size(28.dp)) }
                            IconButton(onClick={player.seekToNextMediaItem()}) { Icon(Icons.Default.SkipNext,null,tint=Color.White) }
                            if(!currentVideo) IconButton(onClick={repeatMode=when(repeatMode){Player.REPEAT_MODE_OFF->Player.REPEAT_MODE_ALL;Player.REPEAT_MODE_ALL->Player.REPEAT_MODE_ONE;else->Player.REPEAT_MODE_OFF};player.repeatMode=repeatMode}) { Icon(if(repeatMode==Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,null,tint=if(repeatMode==Player.REPEAT_MODE_OFF) Color.White else accent) }
                            Spacer(Modifier.width(4.dp)); Text(formatTime(duration),color=Color(0xFFADB3C6),fontSize=10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            if(fullScreenVideo && player != null) {
                AlertDialog(
                    onDismissRequest={ fullScreenVideo=false },
                    containerColor=Color.Black,
                    title={ Text("Video player",color=Color.White) },
                    text={ AndroidView(factory={ ctx -> PlayerView(ctx).apply { useController=true; this.player=player; resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT } }, modifier=Modifier.fillMaxWidth().height(280.dp), update={it.player=player}) },
                    confirmButton={ TextButton(onClick={fullScreenVideo=false}) { Text("Close",color=accent) } }
                )
            }
            if(showSettings) {
                AlertDialog(onDismissRequest={showSettings=false},containerColor=Color(0xFF191D2D),title={Text("Personalize ZenPlayer",color=Color.White)},text={
                    Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("Accent color",color=Color.White,fontWeight=FontWeight.SemiBold)
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            palettes.forEachIndexed { i,p -> Box(Modifier.size(34.dp).clip(CircleShape).background(Color(p.second)).clickable { accentIndex=i;prefs.edit().putInt("accent",i).apply() },contentAlignment=Alignment.Center) { if(i==accentIndex) Icon(Icons.Default.Check,null,tint=Color.Black) } }
                        }
                        Text("Background image",color=Color.White,fontWeight=FontWeight.SemiBold)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick={imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))}) { Text("Choose photo") }
                            TextButton(onClick={bgUri=null;prefs.edit().remove("bg_uri").apply()}) { Text("Remove") }
                        }
                        Text("Image blur: ${blurAmount.toInt()} dp",color=Color.White)
                        Slider(value=blurAmount,onValueChange={blurAmount=it;prefs.edit().putFloat("blur",it).apply()},valueRange=0f..40f,colors=SliderDefaults.colors(thumbColor=accent,activeTrackColor=accent))
                    }
                },confirmButton={TextButton(onClick={showSettings=false}) { Text("Done",color=accent) }})
            }
        }
    }
}
private fun formatTime(ms:Long):String { val s=(ms/1000).coerceAtLeast(0); return "%d:%02d".format(s/60,s%60) }
