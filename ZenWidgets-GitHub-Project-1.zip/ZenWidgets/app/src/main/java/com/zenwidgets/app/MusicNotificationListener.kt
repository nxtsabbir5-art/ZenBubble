package com.zenwidgets.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.media.MediaMetadata
import android.media.session.MediaController
import android.content.ComponentName
import android.content.Context

class MusicNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() { super.onListenerConnected(); refreshMusic() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refreshMusic() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refreshMusic() }
    private fun refreshMusic() {
        try {
            val mgr = getSystemService(Context.MEDIA_SESSION_SERVICE) as android.media.session.MediaSessionManager
            val sessions = mgr.getActiveSessions(ComponentName(this, MusicNotificationListener::class.java))
            val active = sessions.firstOrNull { it.metadata != null }
            val md = active?.metadata
            val p = getSharedPreferences("zen", Context.MODE_PRIVATE)
            p.edit().putString("music_title", md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "No Music")
                .putString("music_artist", md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Tap to play").apply()
            ZenWidgetProvider.updateAll(this)
        } catch (_: Exception) { }
    }
}
