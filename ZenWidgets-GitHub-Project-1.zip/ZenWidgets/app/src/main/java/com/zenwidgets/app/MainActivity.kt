package com.zenwidgets.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.google.android.gms.location.LocationServices
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("zen", Context.MODE_PRIVATE) }
    private lateinit var city: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 36, 24, 24); setBackgroundColor(0xFF080808.toInt()) }
        fun label(s: String, size: Float = 16f) = TextView(this).apply { text = s; textSize = size; setTextColor(-1); setPadding(0, 12, 0, 12) }
        root.addView(label("ZenWidgets", 28f)); root.addView(label("Frosted Glass • Clock • Music • Battery • Weather"))
        root.addView(label("Weather location", 18f))
        city = EditText(this).apply { setTextColor(-1); setHintTextColor(0xFFAAAAAA.toInt()); hint = "Enter city (e.g. Dhaka)"; setSingleLine(); setText(prefs.getString("city", "")) }
        root.addView(city)
        val save = Button(this).apply { text = "Use Manual City"; setOnClickListener { val c = city.text.toString().trim(); if (c.isNotEmpty()) { prefs.edit().putString("mode", "manual").putString("city", c).apply(); refresh(); Toast.makeText(this@MainActivity, "Manual city saved", Toast.LENGTH_SHORT).show() } } }
        root.addView(save)
        val gps = Button(this).apply { text = "Use Automatic GPS"; setOnClickListener { enableGps() } }; root.addView(gps)
        root.addView(label("Music controls need Notification Access so Android can share active media sessions.", 14f))
        root.addView(Button(this).apply { text = "Enable Music Access"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } })
        root.addView(label("Add widget: Long-press home screen → Widgets → ZenWidgets. Resize it to match the reference design.", 14f))
        root.addView(Button(this).apply { text = "Refresh Widget Now"; setOnClickListener { refresh() } })
        setContentView(ScrollView(this).apply { addView(root) })
        scheduleWeather()
    }
    private fun enableGps() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 42); return
        }
        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { loc ->
            if (loc != null) { prefs.edit().putString("mode", "gps").putString("lat", loc.latitude.toString()).putString("lon", loc.longitude.toString()).apply(); refresh(); Toast.makeText(this, "GPS location saved", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(this, "Location unavailable. Turn on Location and try again.", Toast.LENGTH_LONG).show()
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) { super.onRequestPermissionsResult(requestCode, permissions, grantResults); if (requestCode == 42 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) enableGps() }
    private fun refresh() { scheduleWeather(); ZenWidgetProvider.updateAll(this) }
    private fun scheduleWeather() {
        val req = PeriodicWorkRequestBuilder<WeatherWorker>(30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("zen_weather", ExistingPeriodicWorkPolicy.UPDATE, req)
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<WeatherWorker>().build())
    }
}
