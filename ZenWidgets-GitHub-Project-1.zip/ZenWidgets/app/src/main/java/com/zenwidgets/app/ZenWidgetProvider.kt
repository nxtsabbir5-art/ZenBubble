package com.zenwidgets.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.os.BatteryManager
import android.widget.RemoteViews
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.content.ComponentName

class ZenWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) { ids.forEach { update(context, manager, it) } }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action in listOf(A_PLAY, A_PREV, A_NEXT)) sendMediaCommand(context, intent.action!!)
        if (intent.action == Intent.ACTION_BATTERY_CHANGED) updateAll(context)
    }
    companion object {
        const val A_PLAY = "com.zenwidgets.app.PLAY"; const val A_PREV = "com.zenwidgets.app.PREV"; const val A_NEXT = "com.zenwidgets.app.NEXT"
        fun updateAll(c: Context) { val m = AppWidgetManager.getInstance(c); val ids = m.getAppWidgetIds(ComponentName(c, ZenWidgetProvider::class.java)); ids.forEach { update(c, m, it) } }
        private fun update(c: Context, m: AppWidgetManager, id: Int) {
            val v = RemoteViews(c.packageName, R.layout.widget_zen); val p = c.getSharedPreferences("zen", Context.MODE_PRIVATE)
            val fmt = java.text.SimpleDateFormat("EEE, MMM d", java.util.Locale.getDefault()); v.setTextViewText(R.id.date_text, fmt.format(java.util.Date()))
            val battery = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)); val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1; val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
            val batteryStatus = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = batteryStatus == BatteryManager.BATTERY_STATUS_CHARGING || batteryStatus == BatteryManager.BATTERY_STATUS_FULL
            v.setTextViewText(R.id.battery_percent, "$pct%"); v.setTextViewText(R.id.battery_state, if (charging) "Charging" else "Battery")
            v.setTextViewText(R.id.weather_temp, p.getString("temp", "--°C")); v.setTextViewText(R.id.weather_desc, p.getString("weather_desc", "Set location")); v.setTextViewText(R.id.weather_icon, p.getString("weather_icon", "☁"))
            v.setTextViewText(R.id.music_title, p.getString("music_title", "No Music")); v.setTextViewText(R.id.music_artist, p.getString("music_artist", "Enable Music Access"))
            try {
                val sm = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as android.media.session.MediaSessionManager
                val session = sm.getActiveSessions(ComponentName(c, MusicNotificationListener::class.java)).firstOrNull()
                val art = session?.metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)
                    ?: session?.metadata?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART)
                if (art != null) v.setImageViewBitmap(R.id.album_art, art)
                val playing = session?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                v.setImageViewResource(R.id.play_btn, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            } catch (_: SecurityException) { }
            setAction(c, v, R.id.play_btn, A_PLAY); setAction(c, v, R.id.prev_btn, A_PREV); setAction(c, v, R.id.next_btn, A_NEXT)
            m.updateAppWidget(id, v)
        }
        private fun setAction(c: Context, v: RemoteViews, viewId: Int, action: String) { val i = Intent(c, ZenWidgetProvider::class.java).setAction(action); v.setOnClickPendingIntent(viewId, PendingIntent.getBroadcast(c, action.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)) }
        private fun sendMediaCommand(c: Context, action: String) {
            try { val mgr = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager; val sessions = mgr.getActiveSessions(ComponentName(c, MusicNotificationListener::class.java)); val controller = sessions.firstOrNull() ?: return
                when (action) { A_PLAY -> if (controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) controller.transportControls.pause() else controller.transportControls.play(); A_PREV -> controller.transportControls.skipToPrevious(); A_NEXT -> controller.transportControls.skipToNext() }
            } catch (_: SecurityException) { }
        }
    }
}
