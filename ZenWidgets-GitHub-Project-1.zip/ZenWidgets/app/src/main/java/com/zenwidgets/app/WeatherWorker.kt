package com.zenwidgets.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

class WeatherWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val p = applicationContext.getSharedPreferences("zen", Context.MODE_PRIVATE)
            var lat = p.getString("lat", null); var lon = p.getString("lon", null)
            var place = p.getString("city", "") ?: ""
            if (p.getString("mode", "manual") != "gps") {
                if (place.isBlank()) place = "Dhaka"
                val geo = JSONObject(URL("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(place, "UTF-8")}&count=1&language=en&format=json").readText())
                val first = geo.optJSONArray("results")?.optJSONObject(0) ?: return@withContext Result.retry()
                lat = first.getDouble("latitude").toString(); lon = first.getDouble("longitude").toString(); place = first.optString("name", place)
            }
            if (lat == null || lon == null) return@withContext Result.retry()
            val data = JSONObject(URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code,is_day&timezone=auto").readText()).getJSONObject("current")
            val temp = data.getDouble("temperature_2m").toInt()
            val code = data.getInt("weather_code")
            val (desc, icon) = when (code) {
                0 -> "Clear" to (if (data.optInt("is_day") == 1) "☀" else "☾")
                1, 2 -> "Partly Cloudy" to "⛅"
                3 -> "Cloudy" to "☁"
                45, 48 -> "Fog" to "〰"
                in 51..67 -> "Drizzle / Rain" to "🌧"
                in 71..77 -> "Snow" to "❄"
                in 80..82 -> "Rain Showers" to "🌦"
                in 95..99 -> "Thunderstorm" to "⛈"
                else -> "Weather" to "☁"
            }
            p.edit().putString("temp", "$temp°C").putString("weather_desc", desc).putString("weather_icon", icon).putString("place", place).apply()
            ZenWidgetProvider.updateAll(applicationContext)
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }
}
