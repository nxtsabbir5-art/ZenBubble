# ZenWidgets

A Kotlin Android home-screen widget starter inspired by the supplied black frosted-glass reference. It combines a stacked digital clock, media controls, battery status and live weather in one resizable widget.

## Build with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the containing `ZenWidgets` folder).
3. Open **Actions** → **Build ZenWidgets APK** → **Run workflow**. A push to `main` or `master` also starts a build.
4. Open the completed workflow run and download **ZenWidgets-debug-apk** from Artifacts.
5. Install `app-debug.apk` on your Android phone.

## Setup on phone
1. Open ZenWidgets and choose **Use Automatic GPS** or enter a city and tap **Use Manual City**.
2. To enable media-session controls and track current song details, tap **Enable Music Access** and allow ZenWidgets in Android Notification Access settings.
3. Long-press the launcher home screen → Widgets → ZenWidgets. Add and resize the widget.

## Weather source and privacy
Live weather uses the free Open-Meteo forecast and geocoding APIs; no API key is required. Manual mode sends the city name to Open-Meteo geocoding. GPS mode uses Android's location permission and sends latitude/longitude to Open-Meteo. Location is not sent to any custom server by this project. Weather refresh is scheduled every 30 minutes by WorkManager.

## Notes / limitations
- Android home-screen widgets use RemoteViews, which do not support true live background blur or arbitrary custom animations. The supplied design uses translucent dark gradient panels and subtle borders to approximate the frosted-glass appearance; actual blur strength may vary by launcher.
- Music metadata and transport controls require Notification Access. Some music apps restrict session visibility or skip controls.
- The widget is a first buildable baseline. Verify layout and behavior on the target Infinix/XOS launcher; widget rendering and sizing can differ between launchers.
- GPS mode uses the last known device location. Turn on Location and grant location permission; if no last-known location exists, try again after the phone has acquired a fix.
