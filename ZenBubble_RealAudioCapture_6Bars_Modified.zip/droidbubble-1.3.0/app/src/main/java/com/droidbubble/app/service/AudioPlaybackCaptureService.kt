package com.droidbubble.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.AudioPlaybackCaptureConfiguration
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.droidbubble.app.island.AudioSpectrumState
import kotlin.math.PI
import kotlin.math.sqrt
import kotlin.math.ln
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min
import kotlin.math.log10

/** Captures only playback streams that explicitly allow AudioPlaybackCapture. */
class AudioPlaybackCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopCapture(); return START_NOT_STICKY }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || resultData == null) { stopSelf(); return START_NOT_STICKY }
        startForegroundCompat()
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, android.os.Handler(mainLooper))
            startAudioRecord()
        } catch (t: Throwable) {
            Log.e(TAG, "Audio playback capture could not start", t)
            stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val channel = "zenbubble_audio_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channel, "Audio spectrum capture", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(this, 77, Intent(this, AudioPlaybackCaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("ZenBubble audio spectrum")
            .setContentText("Capturing permitted music audio")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(77, notification)
    }

    private fun startAudioRecord() {
        val p = projection ?: return
        val sampleRate = 44100
        val config = AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = max(minBuffer, 4096)
        val audio = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(bufferSize)
            .setAudioPlaybackCaptureConfig(config).build()
        if (audio.state != AudioRecord.STATE_INITIALIZED) { audio.release(); throw IllegalStateException("AudioRecord initialization failed") }
        recorder = audio
        audio.startRecording()
        running = true
        worker = Thread {
            val samples = ShortArray(1024)
            var silenceFrames = 0
            while (running) {
                val count = try { audio.read(samples, 0, samples.size) } catch (_: Throwable) { -1 }
                if (count <= 0) { Thread.sleep(40); continue }
                val rms = sqrt((0 until count).sumOf { val v = samples[it].toDouble() / 32768.0; v * v } / count)
                if (rms < 0.0018) silenceFrames++ else silenceFrames = 0
                if (silenceFrames >= 18) { AudioSpectrumState.clear(); continue }
                val levels = analyzeBands(samples, count)
                AudioSpectrumState.update(levels)
            }
        }.apply { name = "ZenBubbleAudioFFT"; start() }
    }

    private fun analyzeBands(data: ShortArray, count: Int): List<Float> {
        val n = min(count, 1024)
        val bands = arrayOf(1..3, 4..7, 8..14, 15..27, 28..52, 53..110)
        val out = ArrayList<Float>(6)
        for (range in bands) {
            var energy = 0.0
            var bins = 0
            for (k in range) {
                if (k >= n / 2) continue
                var re = 0.0; var im = 0.0
                for (i in 0 until n) {
                    val window = 0.5 - 0.5 * cos(2.0 * PI * i / (n - 1).coerceAtLeast(1))
                    val x = data[i].toDouble() / 32768.0 * window
                    val angle = 2.0 * PI * k * i / n
                    re += x * cos(angle); im -= x * sin(angle)
                }
                energy += sqrt(re * re + im * im) / n
                bins++
            }
            val magnitude = if (bins > 0) energy / bins else 0.0
            val scaled = ((20.0 * log10(magnitude * 180.0 + 1e-6) + 55.0) / 55.0).toFloat()
            out.add(scaled.coerceIn(0f, 1f))
        }
        return out
    }

    private fun stopCapture() {
        running = false
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        AudioSpectrumState.clear()
        worker?.interrupt(); worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { running = false; try { recorder?.release() } catch (_: Throwable) {}; try { projection?.stop() } catch (_: Throwable) {}; AudioSpectrumState.clear(); super.onDestroy() }

    companion object {
        const val ACTION_STOP = "com.droidbubble.app.action.STOP_AUDIO_CAPTURE"
        const val EXTRA_RESULT_CODE = "audio_capture_result_code"
        const val EXTRA_RESULT_DATA = "audio_capture_result_data"
        private const val TAG = "ZenBubbleAudioCapture"
    }
}
