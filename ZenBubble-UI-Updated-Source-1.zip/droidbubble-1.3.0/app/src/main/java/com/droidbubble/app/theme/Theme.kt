package com.droidbubble.app.theme

import androidx.compose.ui.graphics.Color\nimport androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = ColorZenLavender,
    onPrimary = ColorDarkInk,
    primaryContainer = Color(0xFF30264A),
    onPrimaryContainer = Color(0xFFE9DDFF),
    secondary = ColorZenBlue,
    onSecondary = Color(0xFF071827),
    secondaryContainer = Color(0xFF19334A),
    onSecondaryContainer = Color(0xFFD5EAFF),
    tertiary = ColorZenPink,
    background = ColorDarkBackground,
    onBackground = Color(0xFFF2EFF8),
    surface = ColorDarkSurface,
    onSurface = Color(0xFFF2EFF8),
    surfaceVariant = Color(0xFF252131),
    onSurfaceVariant = Color(0xFFC8C1D5),
    surfaceContainerLow = Color(0xFF171420),
    surfaceContainer = Color(0xFF1D1928),
    surfaceContainerHigh = Color(0xFF282336),
    surfaceContainerHighest = Color(0xFF302A40),
    outline = Color(0xFF625B70)
)

private val LightColorScheme = lightColorScheme(
    primary = ColorLightPurple,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE9E0FF),
    onPrimaryContainer = Color(0xFF24134D),
    secondary = ColorLightBlue,
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDCEEFF),
    onSecondaryContainer = Color(0xFF102C48),
    tertiary = Color(0xFFB64C91),
    background = ColorLightBackground,
    onBackground = Color(0xFF191522),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF191522),
    surfaceVariant = Color(0xFFF0EDF7),
    onSurfaceVariant = Color(0xFF5F596C),
    surfaceContainerLow = Color(0xFFF8F6FC),
    surfaceContainer = Color(0xFFF2EFF8),
    surfaceContainerHigh = Color(0xFFECE8F4),
    surfaceContainerHighest = Color(0xFFE5E0EF),
    outline = Color(0xFF8B8498)
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun DroidbubbleTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialExpressiveTheme(
        colorScheme = colorScheme,
        typography = Typography,
        motionScheme = MotionScheme.expressive(),
        content = content
    )
}
