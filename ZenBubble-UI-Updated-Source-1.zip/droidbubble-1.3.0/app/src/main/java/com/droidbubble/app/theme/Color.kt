package com.droidbubble.app.theme

import androidx.compose.ui.graphics.Color

val ColorZenLavender = Color(0xFFB9A2FF)
val ColorZenBlue = Color(0xFF83C5FF)
val ColorZenPink = Color(0xFFFF83C8)
val ColorDarkInk = Color(0xFF171222)
val ColorDarkBackground = Color(0xFF0D0B12)
val ColorDarkSurface = Color(0xFF14111C)
val ColorLightPurple = Color(0xFF7255C7)
val ColorLightBlue = Color(0xFF397FC2)
val ColorLightBackground = Color(0xFFF8F7FC)

// Retained compatibility colors for any existing UI references.
val Purple80 = ColorZenLavender
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = ColorZenPink
val Purple40 = ColorLightPurple
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFFB64C91)
