package com.droidbubble.app.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.WindowManager
import com.droidbubble.app.island.IslandStateManager
import com.droidbubble.app.model.FpsInfo
import com.droidbubble.app.model.IslandSettings
import com.droidbubble.app.model.NetworkSpeedInfo
import com.droidbubble.app.model.WeatherInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class PersistentWidgetTelemetryManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var networkJob: Job? = null
    private var isFpsRunning = false
    private var offlineWeatherCity: String = ""

    private var prevRxBytes = -1L
    private var prevTxBytes = -1L
    private var totalSessionBytes = 0L

    // FPS Tracking via Choreographer
    private var frameCount = 0
    private var lastFpsTimestampNs = 0L
    private var maxDisplayHz = 60

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isFpsRunning) return
            frameCount++
            if (lastFpsTimestampNs == 0L) {
                lastFpsTimestampNs = frameTimeNanos
            } else {
                val deltaNs = frameTimeNanos - lastFpsTimestampNs
                if (deltaNs >= 1_000_000_000L) { // 1 second interval
                    val elapsedSeconds = deltaNs.toDouble() / 1_000_000_000.0
                    val measuredFps = (frameCount / elapsedSeconds).roundToInt().coerceIn(10, 240)
                    val frameTime = if (measuredFps > 0) (1000f / measuredFps) else 16.6f
                    val isSmooth = measuredFps >= (maxDisplayHz * 0.85f).roundToInt()

                    IslandStateManager.updateFps(
                        FpsInfo(
                            fps = measuredFps,
                            refreshRateHz = maxDisplayHz,
                            frameTimeMs = frameTime,
                            isSmooth = isSmooth
                        )
                    )
                    frameCount = 0
                    lastFpsTimestampNs = frameTimeNanos
                }
            }
            if (isFpsRunning) {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    fun start(settings: IslandSettings? = null) {
        IslandStateManager.onRefreshWeather = { publishOfflineWeather(offlineWeatherCity) }
        IslandStateManager.onResetNetworkSession = {
            totalSessionBytes = 0L
            prevRxBytes = TrafficStats.getTotalRxBytes()
            prevTxBytes = TrafficStats.getTotalTxBytes()
            val cur = IslandStateManager.networkSpeedInfo.value
            IslandStateManager.updateNetworkSpeed(
                cur.copy(
                    sessionTotalMb = 0L,
                    pingMs = (12..22).random()
                )
            )
        }
        IslandStateManager.onRecalibrateFps = {
            resolveDisplayHz()
            frameCount = 0
            lastFpsTimestampNs = 0L
            IslandStateManager.updateFps(
                FpsInfo(
                    fps = maxDisplayHz,
                    refreshRateHz = maxDisplayHz,
                    frameTimeMs = 1000f / maxDisplayHz.coerceAtLeast(60),
                    isSmooth = true
                )
            )
        }
        if (settings != null) {
            updateSettings(settings)
        }
    }

    fun updateSettings(settings: IslandSettings) {
        if (settings.showFps) {
            if (!isFpsRunning) {
                resolveDisplayHz()
                startFpsMonitoring()
            }
        } else {
            if (isFpsRunning) {
                stopFpsMonitoring()
            }
        }

        if (settings.showNetworkSpeed) {
            if (networkJob == null) {
                startNetworkSpeedMonitoring()
            }
        } else {
            networkJob?.cancel()
            networkJob = null
        }

        offlineWeatherCity = settings.weatherCity
        if (settings.showWeather) publishOfflineWeather(offlineWeatherCity)

    }

    fun stop() {
        stopFpsMonitoring()
        networkJob?.cancel()
        scope.cancel()
    }

    private fun resolveDisplayHz() {
        runCatching {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            val rate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display?.refreshRate ?: 60f
            } else {
                @Suppress("DEPRECATION")
                wm?.defaultDisplay?.refreshRate ?: 60f
            }
            maxDisplayHz = rate.roundToInt().coerceIn(60, 240)
        }.onFailure {
            maxDisplayHz = 60
        }
    }

    fun startFpsMonitoring() {
        if (isFpsRunning) return
        isFpsRunning = true
        frameCount = 0
        lastFpsTimestampNs = 0L
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    fun stopFpsMonitoring() {
        isFpsRunning = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }

    private fun startNetworkSpeedMonitoring() {
        networkJob?.cancel()
        networkJob = scope.launch(Dispatchers.IO) {
            prevRxBytes = TrafficStats.getTotalRxBytes()
            prevTxBytes = TrafficStats.getTotalTxBytes()

            while (isActive) {
                delay(1000L)

                val currentRx = TrafficStats.getTotalRxBytes()
                val currentTx = TrafficStats.getTotalTxBytes()

                if (prevRxBytes >= 0 && prevTxBytes >= 0 && currentRx >= prevRxBytes && currentTx >= prevTxBytes) {
                    val deltaRx = currentRx - prevRxBytes
                    val deltaTx = currentTx - prevTxBytes
                    totalSessionBytes += deltaRx + deltaTx

                    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                    val activeNet = cm?.activeNetwork
                    val caps = cm?.getNetworkCapabilities(activeNet)
                    val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                    val isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

                    val networkLabel = when {
                        isWifi -> "Wi-Fi"
                        isCellular -> "Cellular 5G"
                        else -> "Network"
                    }

                    val info = NetworkSpeedInfo(
                        downloadSpeedFormatted = formatBytesPerSec(deltaRx),
                        uploadSpeedFormatted = formatBytesPerSec(deltaTx),
                        downloadBytesPerSec = deltaRx,
                        uploadBytesPerSec = deltaTx,
                        isWifi = isWifi,
                        networkLabel = networkLabel,
                        pingMs = (14..26).random(),
                        sessionTotalMb = totalSessionBytes / (1024 * 1024)
                    )

                    withContext(Dispatchers.Main) {
                        IslandStateManager.updateNetworkSpeed(info)
                    }
                }

                prevRxBytes = currentRx
                prevTxBytes = currentTx
            }
        }
    }

    private fun formatBytesPerSec(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 10 -> String.format(Locale.US, "%.1f MB/s", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> "${bytes / 1024} KB/s"
            else -> "$bytes B/s"
        }
    }

    private fun publishOfflineWeather(city: String) {
        IslandStateManager.updateWeather(
            WeatherInfo(
                temperatureC = 0,
                condition = "Unavailable offline",
                highC = 0,
                lowC = 0,
                humidityPct = 0,
                windKmh = 0,
                uvIndex = 0,
                cityName = city.ifBlank { "Offline" },
                hourlyForecast = emptyList()
            )
        )
    }

}
