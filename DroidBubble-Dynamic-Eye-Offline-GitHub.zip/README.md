# DroidBubble Offline Edition

This repository is the offline-focused DroidBubble Android project, prepared for GitHub Actions builds.

## Included changes

- Added an animated Dynamic Eye mascot to the compact island.
- Idle state: sleepy/closed-eye expression with periodic blinking.
- Music state: animated dancing eyes with headphone indicators on both sides; existing album art and media controls remain in the media layout.
- Shake state: accelerometer-driven dizzy head rotation.
- Angry state: repeated shakes trigger an angry red-eye expression.
- Removed the in-app updater, update checker, update notification, and APK download/install flow.
- Removed the updater source file.
- Removed Internet, network-state, Wi-Fi-state, and package-install permissions from the app manifest (including manifest-merger removal rules).
- Weather data is marked unavailable offline instead of showing fabricated live conditions.
- Existing notification listener, media session handling, album art, island settings, and other local features are retained in source.

## Build with GitHub Actions

1. Create a GitHub repository.
2. Upload the **contents of this project folder** to the repository root (do not upload the enclosing folder as a nested directory, and do not upload only the ZIP).
3. Open **Actions** and run **DroidBubble Offline APK** (or push to `main` / `master`).
4. When the workflow succeeds, download `DroidBubble-Offline-debug-apk` from the workflow run's Artifacts section.

The workflow uses JDK 17, Android SDK Platform 36, Build Tools 36.0.0, and the checked-in Gradle wrapper.

## Important notes

- The Dynamic Eye music animation reacts to Android's existing media-session playback state. It is a visual playback-state animation, not a claim of waveform/bass analysis. No new audio-recording permission is used for the eye animation.
- Weather is unavailable while offline; no fake forecast is generated.
- GitHub Actions must have network access to download Gradle and Maven/Google dependencies during the build. The installed APK itself has no Internet permission.
- The APK build has not been executed in this environment because the Gradle distribution host was unreachable. GitHub Actions is the intended build environment.
