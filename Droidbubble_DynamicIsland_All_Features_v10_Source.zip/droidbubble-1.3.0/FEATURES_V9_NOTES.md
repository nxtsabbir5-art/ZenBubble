# Dynamic Island Feature Pack v10

## Implemented in source
- Volume control: expanded Quick Controls panel adjusts the media stream volume with Android AudioManager.
- Brightness control: expanded Quick Controls panel adjusts screen brightness after the user grants Android's Modify System Settings access. If not granted, the panel opens the relevant Android settings page.
- Earbud battery: Quick Controls checks Bluetooth bonded devices for a battery percentage reported by Android (Android 13+). Some earbuds/firmware do not expose a battery level; the panel states when no value is available. Bluetooth Connect permission is requested when enabling the feature.
- Screenshot preview: MediaStore ContentObserver watches newly added images, filters screenshot filenames, loads a reduced-size preview, and expands it in the Island. The user must grant Photos/Media access; this is requested when enabling the setting. Preview auto-dismisses after about five seconds.
- Gesture customization: the selected tap target (Expand / Media / Notifications) is persisted and used by the compact Island tap handler.
- Sound Visualizer: uses the project's existing media-reactive wave/visualizer animation toggle.

## How to use
1. Enable the relevant switches in Appearance & Feedback > Dynamic Island Extras.
2. Long-press the compact Island to open Quick Controls when Volume/Brightness or Earbuds Battery is enabled.
3. Grant Android's Modify System Settings access when asked before adjusting brightness.
4. Grant Photos/Media access for Screenshot Preview. Bluetooth Connect access is required for earbud battery reporting.

## Limitations
- Android/OEM firmware may not publish earbud battery values even when connected.
- Screenshot preview depends on Android MediaStore indexing and the filename containing "screenshot", "screen_shot", or "screen-shot".
- Brightness is the global screen brightness, not per-app brightness.
- Sound Visualizer is the existing media-session wave animation; it is not a microphone-based audio capture visualizer.
- The source has not been compiled in this environment because Gradle 9.1.0 could not be downloaded (network DNS unavailable). Run `./gradlew :app:compileDebugKotlin` or GitHub Actions before installing.
