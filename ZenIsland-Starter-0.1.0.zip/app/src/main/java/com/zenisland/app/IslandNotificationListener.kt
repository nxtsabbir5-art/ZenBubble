package com.zenisland.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Ignore ZenIsland's own persistent foreground notification.
        if (sbn.packageName == packageName) return
        IslandService.wake(this)
    }
}
