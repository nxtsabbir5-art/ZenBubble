package com.zenisland.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Typeface
import android.view.View
import android.view.MotionEvent

class IslandService : Service() {
    private lateinit var windowManager: WindowManager
    private var island: TextView? = null
    private var awakeUntil = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "zenisland_service")
                .setContentTitle("ZenIsland is active")
                .setContentText("Your floating island is running")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("ZenIsland is active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build()
        }
        startForeground(1001, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showIsland()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "zenisland_service", "ZenIsland", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showIsland() {
        if (island != null) return
        val view = TextView(this).apply {
            text = " ˘ ˘ "
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            setPadding(44, 12, 44, 12)
            elevation = 20f
            setOnClickListener {
                text = if (text.toString().contains("˘")) "◉ ◉" else "˘ ˘"
                awakeUntil = System.currentTimeMillis() + 4000
            }
            setOnTouchListener { v, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    awakeUntil = System.currentTimeMillis() + 4000
                }
                false
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 18
        }
        windowManager.addView(view, params)
        island = view
        view.post(object : Runnable {
            override fun run() {
                val v = island ?: return
                if (System.currentTimeMillis() > awakeUntil) {
                    v.text = "˘ ˘"
                }
                v.postDelayed(this, 1200)
            }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra("wake", false) == true) {
            awakeUntil = System.currentTimeMillis() + 5000
            island?.text = "◉ ◉"
        }
        return START_STICKY
    }

    override fun onDestroy() {
        island?.let { windowManager.removeView(it) }
        island = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun wake(context: android.content.Context) {
            val i = Intent(context, IslandService::class.java).putExtra("wake", true)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i)
            else context.startService(i)
        }
    }
}
