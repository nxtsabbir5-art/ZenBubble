# ZenIsland (starter 0.1.0)

A minimal Kotlin Android starter for a separate Dynamic Island-style overlay app.

## Current starter scope
- Basic setup screen
- Overlay permission flow
- Notification-listener permission flow
- Foreground overlay service
- Minimal sleeping-eyes pill; tap toggles awake/sleep appearance
- Incoming notifications request the service to wake

## Build
Open this folder in Android Studio with JDK 17 and let Gradle sync.
Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important
This is an early starter, not a finished release. Android may restrict background
foreground-service starts depending on OS version and app state. The notification
listener and overlay require the user to enable their permissions manually.
The current sample does not yet include real notification text rendering, music
detection, charging/battery expressions, manual expression settings, animations,
or persistence/reboot handling. Test on a real device before daily use.
