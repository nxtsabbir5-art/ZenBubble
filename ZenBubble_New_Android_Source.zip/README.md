# ZenBubble — New Android Dynamic Island

This is a new standalone Android project, separate from Droidbubble.

## Open and build
1. Extract the ZIP.
2. Open the extracted `ZenBubble_New_Android` folder in Android Studio.
3. Wait for Gradle sync, then choose Build > Build APK(s).

## First launch
1. Allow **Display over other apps**.
2. Enable **Notification access** for ZenBubble.
3. Return to the app and tap **Start ZenBubble**.

The first version includes a floating black pill, tap-to-expand now-playing panel, and previous/play-pause/next controls. Media details depend on the player exposing an Android media session. Call, charging, notification previews, album-art display, and polished spring animations are planned for a later iteration. Android may show a special-use foreground-service disclosure/permission depending on OS version and distribution channel.
