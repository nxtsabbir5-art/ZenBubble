package com.zenbubble.app

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MediaListener : NotificationListenerService() {
    override fun onListenerConnected() { super.onListenerConnected(); refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()
    private fun refresh() {
        try {
            val mgr = getSystemService(MEDIA_SESSION_SERVICE) as android.media.session.MediaSessionManager
            val tokens: List<MediaSession.Token> = mgr.getActiveSessions(ComponentName(this, MediaListener::class.java))
            val c = tokens.firstOrNull()?.let { MediaController(this, it) }
            IslandState.controller = c
            IslandState.title = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "ZenBubble"
            IslandState.artist = c?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Ready for music"
            IslandState.playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
            IslandState.update()
        } catch (_: Exception) { }
    }
}
