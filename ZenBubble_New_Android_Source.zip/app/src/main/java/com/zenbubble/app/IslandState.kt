package com.zenbubble.app

import android.media.session.MediaController

object IslandState {
    @Volatile var title = "ZenBubble"
    @Volatile var artist = "Tap to expand"
    @Volatile var playing = false
    @Volatile var controller: MediaController? = null
    @Volatile var listener: (() -> Unit)? = null
    fun update() { listener?.invoke() }
}
