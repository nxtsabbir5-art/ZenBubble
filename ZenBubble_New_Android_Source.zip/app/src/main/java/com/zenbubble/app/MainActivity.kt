package com.zenbubble.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 24)
            setBackgroundColor(0xFF090A0F.toInt())
        }
        box.addView(TextView(this).apply { text = "ZenBubble"; textSize = 30f; setTextColor(-1) })
        box.addView(TextView(this).apply {
            text = "iPhone-style Dynamic Island"; textSize = 14f
            setTextColor(0xFFB8BBC7.toInt()); setPadding(0, 8, 0, 24)
        })
        box.addView(button("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        box.addView(button("2. Enable notification access") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        box.addView(button("3. Start ZenBubble") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val i = Intent(this, IslandService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        })
        setContentView(box)
    }
    private fun button(label: String, click: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { click() }
    }
}
