package com.zenbubble.app

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : Service() {
    private lateinit var manager: WindowManager
    private var pill: LinearLayout? = null
    private var expanded = false
    private val handler by lazy { Handler(mainLooper) }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel("zenbubble", "ZenBubble", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, "zenbubble")
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("ZenBubble is active")
            .setContentText("Dynamic Island overlay running").setContentIntent(pending).setOngoing(true).build()
        startForeground(7, notification)
        manager = getSystemService(WINDOW_SERVICE) as WindowManager
        IslandState.listener = { handler.post { render() } }
        createPill()
    }

    private fun createPill() {
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                setColor(0xFF050506.toInt()); cornerRadius = dp(32).toFloat()
                setStroke(dp(1), 0xFF292B35.toInt())
            }
            elevation = dp(12).toFloat()
            setOnClickListener { expanded = !expanded; render() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
        manager.addView(pill, params)
        render()
    }

    private fun render() {
        val v = pill ?: return
        v.removeAllViews()
        val label = TextView(this).apply {
            text = if (expanded) "●  NOW PLAYING" else "●  ZENBUBBLE"
            textSize = 10f; setTextColor(0xFFB8F7D4.toInt()); gravity = Gravity.CENTER
        }
        v.addView(label)
        if (expanded) {
            v.addView(TextView(this).apply {
                text = IslandState.title; textSize = 15f; setTextColor(Color.WHITE)
                gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(2))
            })
            v.addView(TextView(this).apply {
                text = IslandState.artist; textSize = 12f; setTextColor(0xFFB5B8C5.toInt()); gravity = Gravity.CENTER
            })
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            row.addView(control("Previous") { mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) })
            row.addView(control(if (IslandState.playing) "Pause" else "Play") {
                mediaKey(if (IslandState.playing) android.view.KeyEvent.KEYCODE_MEDIA_PAUSE else android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
            })
            row.addView(control("Next") { mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT) })
            v.addView(row)
        }
        try { manager.updateViewLayout(v, v.layoutParams) } catch (_: Exception) { }
    }

    private fun control(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 11f; setTextColor(Color.WHITE); setPadding(dp(10), dp(10), dp(10), dp(8))
        setOnClickListener { action() }
    }
    private fun mediaKey(code: Int) {
        try { IslandState.controller?.dispatchMediaButtonEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code)) } catch (_: Exception) { }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        IslandState.listener = null
        try { pill?.let { manager.removeView(it) } } catch (_: Exception) { }
        pill = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
