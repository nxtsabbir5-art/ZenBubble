package com.droidbubble.app.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = androidx.compose.ui.graphics.Color(0xFFB79CFF),
  onPrimary = androidx.compose.ui.graphics.Color(0xFF1B1030),
  secondary = androidx.compose.ui.graphics.Color(0xFF8BD8F2),
  onSecondary = androidx.compose.ui.graphics.Color(0xFF08212B),
  tertiary = androidx.compose.ui.graphics.Color(0xFFFFA9C8),
  background = androidx.compose.ui.graphics.Color(0xFF090B14),
  onBackground = androidx.compose.ui.graphics.Color(0xFFF2F0F8),
  surface = androidx.compose.ui.graphics.Color(0xFF111522),
  onSurface = androidx.compose.ui.graphics.Color(0xFFF2F0F8),
  surfaceVariant = androidx.compose.ui.graphics.Color(0xFF1A2030),
  onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFFADB5C8),
  outline = androidx.compose.ui.graphics.Color(0xFF343D55),
  error = androidx.compose.ui.graphics.Color(0xFFFF7895)
)

private val LightColorScheme =
  lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF7250C9),
    secondary = androidx.compose.ui.graphics.Color(0xFF277E9E),
    tertiary = androidx.compose.ui.graphics.Color(0xFFC04D7D),
    background = androidx.compose.ui.graphics.Color(0xFFFAF8FC),
    surface = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFF0ECF7),
    outline = androidx.compose.ui.graphics.Color(0xFFD8D0E5)
  )

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun DroidbubbleTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialExpressiveTheme(
    colorScheme = colorScheme,
    typography = Typography,
    motionScheme = MotionScheme.expressive(),
    content = content
  )
}
