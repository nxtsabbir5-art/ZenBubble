# ZenBubble Anime Minimal UI + Island Touch Reinitialization Fix

Base: user-provided droidbubble-1.3.0-fixed.zip.

## UI
- Replaced Android dynamic color with a consistent anime-minimal palette: ink/navy surfaces, violet primary, soft cyan secondary, sakura accent.
- Added ZenBubble wordmark/header and a compact service-status indicator to the home screen.
- Reduced home page spacing slightly for a cleaner, less card-heavy layout.
- Existing pages and settings remain available; their Material components inherit the new palette.

## Overlay OFF -> ON touch fix
- Overlay-specific state and keyboard collectors now live in an overlay-scoped coroutine scope.
- Those collectors are cancelled whenever the overlay view is removed, preventing stale collectors from holding old view/window references after repeated enable/disable cycles.
- Settings listener is tracked separately and replaced on reinitialization, avoiding duplicate settings collectors.
- Overlay removal now uses removeViewImmediate, clears stale LayoutParams, cancels pending collapse jobs, and resets expansion/collapse bookkeeping.
- Every new overlay attachment forces WindowManager to commit fresh touchable bounds.

## Validation
- ZIP integrity and basic Kotlin delimiter checks passed.
- No Gradle compile or device runtime test was available in this environment. Please run the GitHub Actions build and test OFF -> ON touch behavior on the phone.
