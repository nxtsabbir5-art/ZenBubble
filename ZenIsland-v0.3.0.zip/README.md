# ZenIsland 0.3.0

Android Kotlin Dynamic Island prototype with:
- Animated minimal-eye face and tap-to-expand/collapse animation
- Automatic charging / unplugged state detection
- Active Android media-session detection (requires Notification Access)
- Manual expressions
- Preset glow themes and custom hue slider
- Overlay and notification-listener setup screen

## Build
Open in Android Studio with JDK 17, or use the repository GitHub Actions workflow.
The root Gradle plugin versions and module JVM targets are configured for Java 17.

## Permissions and limitations
- Enable Display over other apps for the floating island.
- Enable Notification Access for notification wake-up and MediaSessionManager access.
- Media detection works for apps exposing an Android media session; some apps may not expose playback state.
- Charging detection uses Android's battery status broadcast.
- Android may restrict foreground service starts or overlay behavior depending on device firmware and battery settings.
- This is still an early build, not a polished commercial release. Test on device and review logs.
