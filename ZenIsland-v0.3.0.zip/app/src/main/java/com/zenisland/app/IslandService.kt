package com.zenisland.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.*
import android.graphics.PixelFormat
import android.media.session.PlaybackState
import android.media.session.MediaSessionManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.animation.ValueAnimator
import android.view.animation.AccelerateDecelerateInterpolator
import android.content.ComponentName

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var face: FaceView? = null
    private lateinit var params: WindowManager.LayoutParams
    private var expanded = false
    private var manualUntil = 0L
    private var currentActivity = "sleep"
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("zenisland", MODE_PRIVATE) }
    private var batteryReceiver: BroadcastReceiver? = null

    private val monitor = object : Runnable {
        override fun run() {
            detectMediaPlayback()
            if (System.currentTimeMillis() > manualUntil && prefs.getBoolean("automatic", true)) {
                if (currentActivity != "music" && currentActivity != "charging") {
                    setExpression("sleep")
                }
            }
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "zenisland_service")
                .setContentTitle("ZenIsland is active")
                .setContentText("Music, charging and expressions are monitored")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true).build()
        else @Suppress("DEPRECATION") Notification.Builder(this)
            .setContentTitle("ZenIsland is active")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(1001, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showIsland()
        registerBatteryReceiver()
        handler.post(monitor)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("zenisland_service", "ZenIsland", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showIsland() {
        if (face != null) return
        val view = FaceView(this).apply {
            expression = prefs.getString("expression", "sleep") ?: "sleep"
            themeName = prefs.getString("theme", "blue") ?: "blue"
            customHue = prefs.getFloat("customHue", 225f)
            compact = true
            setOnClickListener { toggleExpand() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            dp(148), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(4) }
        wm.addView(view, params)
        face = view
    }

    private fun toggleExpand() {
        val view = face ?: return
        expanded = !expanded
        view.expanded = expanded
        view.compact = !expanded
        val startW = params.width
        val startH = params.height
        val endW = dp(if (expanded) 310 else 148)
        val endH = dp(if (expanded) 104 else 58)
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 320
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val fraction = it.animatedValue as Float
                params.width = (startW + (endW - startW) * fraction).toInt()
                params.height = (startH + (endH - startH) * fraction).toInt()
                try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
            }
            start()
        }
        if (expanded) {
            manualUntil = System.currentTimeMillis() + 6000
            if (currentActivity == "sleep") setExpression("normal")
        }
    }

    private fun registerBatteryReceiver() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL || plugged != 0
                if (charging && prefs.getBoolean("automatic", true)) {
                    currentActivity = "charging"
                    setExpression("charging")
                } else if (currentActivity == "charging") {
                    currentActivity = "normal"
                    setExpression("happy")
                    manualUntil = System.currentTimeMillis() + 3500
                }
            }
        }
        batteryReceiver = receiver
        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun detectMediaPlayback() {
        if (!prefs.getBoolean("automatic", true)) return
        try {
            val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val component = ComponentName(this, IslandNotificationListener::class.java)
            val controllers = manager.getActiveSessions(component)
            val playing = controllers.any { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            if (playing && currentActivity != "charging") {
                currentActivity = "music"
                setExpression("music")
            } else if (!playing && currentActivity == "music") {
                currentActivity = "normal"
                setExpression("normal")
                manualUntil = System.currentTimeMillis() + 2500
            }
        } catch (_: SecurityException) {
            // Notification access has not been granted yet.
        } catch (_: Exception) {
            // Media session may be temporarily unavailable.
        }
    }

    private fun setExpression(value: String) {
        face?.let {
            it.expression = value
            it.themeName = prefs.getString("theme", "blue") ?: "blue"
            it.customHue = prefs.getFloat("customHue", 225f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val requested = intent?.getStringExtra("expression")
        val theme = intent?.getStringExtra("theme")
        if (theme != null) {
            prefs.edit().putString("theme", theme).apply()
            face?.themeName = theme
            face?.customHue = prefs.getFloat("customHue", 225f)
            face?.invalidate()
        }
        val hue = intent?.getFloatExtra("customHue", -1f) ?: -1f
        if (hue >= 0f) {
            prefs.edit().putFloat("customHue", hue).apply()
            face?.customHue = hue
            face?.themeName = "custom"
        }
        if (requested != null) {
            currentActivity = requested
            manualUntil = System.currentTimeMillis() + 8000
            setExpression(requested)
        }
        if (intent?.getBooleanExtra("wake", false) == true) {
            currentActivity = "normal"
            manualUntil = System.currentTimeMillis() + 8000
            setExpression("normal")
        }
        return START_STICKY
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(monitor)
        batteryReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        face?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        face = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun wake(context: Context) {
            val intent = Intent(context, IslandService::class.java).putExtra("wake", true)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }
}
