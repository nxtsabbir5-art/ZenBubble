package com.zenisland.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.abs
import kotlin.math.sin

class FaceView(context: Context) : View(context) {
    var expression: String = "sleep"
        set(value) { field = value; invalidate() }
    var compact = true
        set(value) { field = value; invalidate() }
    var expanded = false
        set(value) { field = value; invalidate() }
    var themeName: String = "blue"
        set(value) { field = value; invalidate() }
    var customHue: Float = 225f
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    init { animator.start() }

    private fun accent(): Int {
        val hue = when (themeName) {
            "mint" -> 155f
            "violet" -> 270f
            "rose" -> 340f
            "custom" -> customHue
            else -> 220f
        }
        return Color.HSVToColor(floatArrayOf(hue, .58f, 1f))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val accent = accent()
        val pill = RectF(w * .025f, h * .08f, w * .975f, h * .92f)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(3, 5, 11)
        paint.setShadowLayer(if (expanded) 24f else 14f, 0f, 4f, (accent and 0x00FFFFFF) or (105 shl 24))
        canvas.drawRoundRect(pill, h * .43f, h * .43f, paint)
        paint.clearShadowLayer()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = if (expanded) 2.2f else 1.4f
        paint.color = (accent and 0x00FFFFFF) or ((if (expanded) 180 else 115) shl 24)
        canvas.drawRoundRect(pill, h * .43f, h * .43f, paint)
        paint.style = Paint.Style.FILL

        val centerY = if (expanded) h * .43f else h * .50f
        val eyeX1 = if (expanded) w * .34f else w * .39f
        val eyeX2 = if (expanded) w * .54f else w * .61f
        val eyeW = if (expanded) h * .105f else h * .115f
        val eyeH = h * .19f
        val blink = abs(sin(phase * Math.PI)).toFloat()
        val openH = when (expression) {
            "sleep" -> h * .022f
            "happy" -> h * .035f
            "sad" -> eyeH * .70f
            "angry" -> eyeH * .68f
            else -> eyeH * (.30f + .70f * blink)
        }
        val eyeColor = when (expression) {
            "happy" -> Color.rgb(105, 245, 190)
            "sad" -> Color.rgb(120, 185, 255)
            "angry" -> Color.rgb(255, 105, 125)
            "music" -> accent
            "charging" -> Color.rgb(255, 220, 105)
            else -> Color.rgb(242, 246, 255)
        }

        for (cx in listOf(eyeX1, eyeX2)) {
            paint.color = eyeColor
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = h * .035f
            if (expression == "sleep" || expression == "happy") {
                val arc = RectF(cx - eyeW, centerY - openH * 1.5f, cx + eyeW, centerY + openH * 1.5f)
                canvas.drawArc(arc, 15f, 150f, false, paint)
            } else {
                paint.style = Paint.Style.FILL
                val eye = RectF(cx - eyeW, centerY - openH, cx + eyeW, centerY + openH)
                canvas.drawRoundRect(eye, eyeW * .8f, eyeW * .8f, paint)
            }
        }

        if (expanded) {
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(190, 199, 220)
            paint.textSize = h * .13f
            paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            val label = when (expression) {
                "music" -> "MUSIC PLAYING"
                "charging" -> "CHARGING"
                "happy" -> "HAPPY"
                "sad" -> "LOW BATTERY"
                "angry" -> "ALERT"
                "sleep" -> "SLEEPING"
                else -> "ZENISLAND"
            }
            canvas.drawText(label, w * .68f, h * .48f, paint)
        }

        if (expression == "music" || expression == "charging") {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = if (expression == "charging") Color.rgb(255, 220, 105) else accent
            val bars = if (expanded) 4 else 3
            for (i in 0 until bars) {
                val x = w * (.78f + i * .045f)
                val amp = h * (.10f + .13f * abs(sin(phase * 5f + i)).toFloat())
                canvas.drawLine(x, centerY - amp, x, centerY + amp, paint)
            }
        }
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }
}
