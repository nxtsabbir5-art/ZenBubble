package com.zenisland.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("zenisland", MODE_PRIVATE) }
    private lateinit var preview: FaceView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(30))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8,11,22), Color.rgb(18,22,42), Color.rgb(8,11,22)))
        }
        val brand = TextView(this).apply {
            text = "◈  ZENISLAND"
            textSize = 13f
            letterSpacing = .22f
            setTextColor(Color.rgb(151,169,255))
            typeface = Typeface.DEFAULT_BOLD
        }
        val heading = TextView(this).apply {
            text = "A little life\nin your island."
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(5))
        }
        val sub = TextView(this).apply {
            text = "Your island sleeps, wakes and reacts."
            textSize = 14f
            setTextColor(Color.rgb(174,183,207))
        }
        preview = FaceView(this).apply {
            expression = prefs.getString("expression", "sleep") ?: "sleep"
            expanded = true
            compact = false
            themeName = prefs.getString("theme", "blue") ?: "blue"
            customHue = prefs.getFloat("customHue", 225f)
        }
        val previewWrap = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(20))
            addView(preview, LinearLayout.LayoutParams(-1, dp(130)))
        }
        status = TextView(this).apply {
            text = "●  READY · AUTOMATIC REACTIONS"
            textSize = 11f
            letterSpacing = .08f
            setTextColor(Color.rgb(125,235,190))
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(18))
        }
        page.addView(brand); page.addView(heading); page.addView(sub)
        page.addView(previewWrap); page.addView(status)
        page.addView(section("QUICK SETUP"))
        page.addView(actionButton("Enable display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        page.addView(actionButton("Enable notification access (music + alerts)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        page.addView(actionButton("Start ZenIsland") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, IslandService::class.java).putExtra("expression", currentExpression()))
                status.text = "●  ISLAND ACTIVE"
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        page.addView(section("MANUAL EXPRESSIONS"))
        val expressions = listOf("sleep" to "Sleep", "normal" to "Awake", "happy" to "Happy",
            "sad" to "Sad", "angry" to "Angry", "music" to "Music")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        expressions.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { (key, label) ->
                val b = actionButton(label) {
                    prefs.edit().putString("expression", key).apply()
                    preview.expression = key
                    status.text = "●  ${label.uppercase()} EXPRESSION"
                    sendUpdate(expression = key)
                }
                row.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            grid.addView(row)
        }
        page.addView(grid)
        page.addView(section("BEHAVIOUR"))
        val automatic = Switch(this).apply {
            text = "Automatic reactions"
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("automatic", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("automatic", checked).apply()
                sendUpdate(expression = currentExpression())
            }
        }
        page.addView(automatic)
        page.addView(section("THEME CUSTOMIZATION"))
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("blue", "mint", "violet", "rose").forEach { theme ->
            val b = actionButton(theme.replaceFirstChar { it.uppercase() }) {
                prefs.edit().putString("theme", theme).apply()
                preview.themeName = theme
                sendUpdate(theme = theme)
            }
            themes.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        page.addView(themes)
        val hueLabel = TextView(this).apply {
            text = "Custom glow colour"
            textSize = 14f
            setTextColor(Color.rgb(190,198,220))
            setPadding(0, dp(14), 0, dp(4))
        }
        page.addView(hueLabel)
        val hue = SeekBar(this).apply {
            max = 359
            progress = prefs.getFloat("customHue", 225f).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        prefs.edit().putFloat("customHue", progress.toFloat()).putString("theme", "custom").apply()
                        preview.themeName = "custom"
                        preview.customHue = progress.toFloat()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    sendUpdate(theme = "custom", hue = progress.toFloat())
                }
            })
        }
        page.addView(hue)
        page.addView(section("LIVE FEATURES"))
        page.addView(infoText("♫  Music: detects active Android media sessions. Notification Access is required."))
        page.addView(infoText("⚡  Charging: reacts to charging and unplugging using the battery status broadcast."))
        page.addView(infoText("↕  Expand: tap the floating island to expand or collapse it with animation."))
        val footer = TextView(this).apply {
            text = "ZENISLAND  •  VERSION 0.3\nMusic · Charging · Themes · Animated Island"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(112,124,153))
            setPadding(0, dp(28), 0, dp(5))
        }
        page.addView(footer)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun currentExpression() = prefs.getString("expression", "sleep") ?: "sleep"

    private fun sendUpdate(expression: String? = null, theme: String? = null, hue: Float? = null) {
        val i = Intent(this, IslandService::class.java)
        expression?.let { i.putExtra("expression", it) }
        theme?.let { i.putExtra("theme", it) }
        hue?.let { i.putExtra("customHue", it) }
        try { startForegroundService(i) } catch (_: Exception) {
            try { startService(i) } catch (_: Exception) {}
        }
    }

    private fun section(label: String) = TextView(this).apply {
        text = label
        textSize = 11f
        letterSpacing = .15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(132,151,218))
        setPadding(0, dp(22), 0, dp(10))
    }

    private fun infoText(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 13f
        setTextColor(Color.rgb(185,194,216))
        setPadding(dp(4), dp(5), dp(4), dp(5))
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(Color.rgb(35,43,72))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.rgb(69,83,130))
        }
        setOnClickListener { action() }
    }
}
