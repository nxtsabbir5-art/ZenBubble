# ZenIsland 0.4.0

A small Android Dynamic Island-style overlay project (Kotlin, Java 17, Android SDK 35).

## Implemented in this update
- Media-session detection through Android Notification Access.
- Headphone graphic animation around both eyes while media playback is active; it disappears when playback stops.
- Notification listener sends a title/body event to the overlay, which expands with a spring-style damped animation and auto-dismisses when enabled.
- Charging-state detection using `ACTION_BATTERY_CHANGED`.
- Blue, mint, violet, rose and custom-hue theme controls.
- Settings controls for activity visibility, notification behavior, media appearance preferences, island dimensions and animation speed.
- Spring-style expand/collapse animation.

## Android limitations / not yet implemented
Some settings are preference/UI switches only in this starter and need separate platform integrations before they can display real data: weather/location, FPS, Wi-Fi throughput, ring mode, airplane mode, Bluetooth connection state, screen-recording state, phone-call state, album-art blur/vinyl/progress visuals, font picker, drag/swipe activity swapping, and full media transport controls. Android/OEM permission and background-execution restrictions may also affect notification and media detection.

## Build
Use JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.7:

```bash
gradle --no-daemon :app:assembleDebug
```

The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.
