package com.zenisland.app

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.media.session.PlaybackState
import android.media.session.MediaSessionManager
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.animation.ValueAnimator
import android.view.animation.TimeInterpolator
import android.content.ComponentName
import kotlin.math.cos
import kotlin.math.exp

class IslandService : Service() {
    private lateinit var wm:WindowManager;private var face:FaceView?=null;private lateinit var params:WindowManager.LayoutParams
    private var expanded=false;private var manualUntil=0L;private var currentActivity="sleep"
    private val handler=Handler(Looper.getMainLooper());private val prefs by lazy{getSharedPreferences("zenisland",MODE_PRIVATE)}
    private var batteryReceiver:BroadcastReceiver?=null;private var noticeReceiver:BroadcastReceiver?=null
    private val monitor=object:Runnable{override fun run(){detectMedia();if(System.currentTimeMillis()>manualUntil&&prefs.getBoolean("automatic",true)&&currentActivity!="music"&&currentActivity!="charging"&&face?.hasPopup()!=true)setExpression("sleep");handler.postDelayed(this,1200)}}
    override fun onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("zenisland_service","ZenIsland",NotificationManager.IMPORTANCE_LOW));val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,"zenisland_service").setContentTitle("ZenIsland is active").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("ZenIsland is active").setSmallIcon(android.R.drawable.ic_dialog_info).build();startForeground(1001,n);wm=getSystemService(WINDOW_SERVICE)as WindowManager;showIsland();registerBattery();registerNotice();handler.post(monitor)}
    private fun showIsland(){if(face!=null)return;val v=FaceView(this).apply{expression=prefs.getString("expression","sleep")?:"sleep";themeName=prefs.getString("theme","violet")?:"violet";customHue=prefs.getFloat("customHue",270f);applyPrefs();compact=true;setOnClickListener{toggleExpand()}}
        val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val pos=prefs.getString("position","center");val grav=Gravity.TOP or if(pos=="left")Gravity.LEFT else Gravity.CENTER_HORIZONTAL
        params=WindowManager.LayoutParams(dp(prefs.getInt("width",148)),dp(prefs.getInt("height",58)),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=grav;x=dp(prefs.getInt("horizontal_offset",0));y=dp(prefs.getInt("top_offset",4))};try{wm.addView(v,params);face=v}catch(_:Exception){}}
    private fun FaceView.applyPrefs(){glassEnabled=prefs.getBoolean("glass_effect",false);glassOpacity=prefs.getInt("glass_opacity",60);outlineEnabled=prefs.getBoolean("island_outline",true);outlineThickness=prefs.getInt("outline_thickness",2).toFloat();bubbleEffect=prefs.getBoolean("bubble_effect",true);fontStyle=prefs.getString("font_style","sans")?:"sans"}
    private fun spring()=ValueAnimator.ofFloat(0f,1f).apply{duration=(500L*100/prefs.getInt("animation_speed",100).coerceIn(40,160)).coerceAtLeast(180);interpolator=TimeInterpolator{t->(1.0-exp(-7.5*t)*cos(11.0*t)).toFloat()}}
    private fun resize(width:Int,height:Int){val v=face?:return;val sw=params.width;val sh=params.height;val ew=dp(width);val eh=dp(height);spring().apply{addUpdateListener{val f=it.animatedValue as Float;params.width=(sw+(ew-sw)*f).toInt();params.height=(sh+(eh-sh)*f).toInt();try{wm.updateViewLayout(v,params)}catch(_:Exception){}};start()}}
    private fun toggleExpand(){val v=face?:return;expanded=!expanded;v.expanded=expanded;v.compact=!expanded;resize(if(expanded)310 else prefs.getInt("width",148),if(expanded)116 else prefs.getInt("height",58));if(expanded){manualUntil=System.currentTimeMillis()+6000;if(currentActivity=="sleep")setExpression("normal");if(prefs.getBoolean("haptics",true))v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)}}
    private fun registerBattery(){val r=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){val s=i?.getIntExtra(BatteryManager.EXTRA_STATUS,-1)?:-1;val plug=i?.getIntExtra(BatteryManager.EXTRA_PLUGGED,0)?:0;val charging=s==BatteryManager.BATTERY_STATUS_CHARGING||s==BatteryManager.BATTERY_STATUS_FULL||plug!=0;if(charging&&prefs.getBoolean("activity_charging",true)&&prefs.getBoolean("automatic",true)){currentActivity="charging";setExpression("charging")}else if(currentActivity=="charging"){currentActivity="normal";setExpression("happy");manualUntil=System.currentTimeMillis()+3000}}};batteryReceiver=r;registerReceiver(r,IntentFilter(Intent.ACTION_BATTERY_CHANGED))}
    private fun registerNotice(){val r=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){if(!prefs.getBoolean("activity_notifications",true))return;val v=face?:return;v.showPopup(i?.getStringExtra("title")?:"Notification",i?.getStringExtra("body")?:"New notification");val was=expanded;expanded=true;v.expanded=true;v.compact=false;resize(320,118);handler.postDelayed({v.clearPopup();if(!was){expanded=false;v.expanded=false;v.compact=true;resize(prefs.getInt("width",148),prefs.getInt("height",58))}},if(prefs.getBoolean("auto_dismiss",true))4500L else 9000L)}};noticeReceiver=r;val f=IntentFilter(ACTION_NOTICE);if(Build.VERSION.SDK_INT>=33)registerReceiver(r,f,Context.RECEIVER_NOT_EXPORTED)else @Suppress("DEPRECATION") registerReceiver(r,f)}
    private fun detectMedia(){if(!prefs.getBoolean("automatic",true)||!prefs.getBoolean("activity_media",true))return;try{val m=getSystemService(MEDIA_SESSION_SERVICE)as MediaSessionManager;val c=ComponentName(this,IslandNotificationListener::class.java);val playing=m.getActiveSessions(c).any{it.playbackState?.state==PlaybackState.STATE_PLAYING};if(playing&&currentActivity!="charging"){currentActivity="music";setExpression("music")}else if(!playing&&currentActivity=="music"){currentActivity="normal";setExpression("normal");manualUntil=System.currentTimeMillis()+2000}}catch(_:Exception){}}
    private fun setExpression(v:String){face?.let{it.expression=v;it.musicActive=v=="music";it.themeName=prefs.getString("theme","violet")?:"violet";it.customHue=prefs.getFloat("customHue",270f);it.applyPrefs()}}
    override fun onStartCommand(i:Intent?,flags:Int,id:Int):Int{val e=i?.getStringExtra("expression");if(e!=null){currentActivity=e;manualUntil=System.currentTimeMillis()+8000;setExpression(e)};val t=i?.getStringExtra("theme");if(t!=null)prefs.edit().putString("theme",t).apply();val hue=i?.getFloatExtra("customHue",-1f)?:-1f;if(hue>=0)prefs.edit().putFloat("customHue",hue).putString("theme","custom").apply();face?.let{it.themeName=prefs.getString("theme","violet")?:"violet";it.customHue=prefs.getFloat("customHue",270f);it.applyPrefs()};return START_STICKY}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onDestroy(){handler.removeCallbacks(monitor);batteryReceiver?.let{try{unregisterReceiver(it)}catch(_:Exception){}};noticeReceiver?.let{try{unregisterReceiver(it)}catch(_:Exception){}};face?.let{try{wm.removeView(it)}catch(_:Exception){}};face=null;super.onDestroy()}
    override fun onBind(i:Intent?):IBinder?=null
    companion object{const val ACTION_NOTICE="com.zenisland.app.NEW_NOTICE";fun wake(c:Context){val i=Intent(c,IslandService::class.java);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i)else c.startService(i)}}
}
