package com.zenisland.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

class FaceView(context: Context) : View(context) {
    var expression="sleep"; set(v){field=v;invalidate()}
    var compact=true; set(v){field=v;invalidate()}
    var expanded=false; set(v){field=v;invalidate()}
    var themeName="violet"; set(v){field=v;invalidate()}
    var customHue=270f; set(v){field=v;invalidate()}
    var musicActive=false; set(v){field=v;invalidate()}
    var glassEnabled=false; var glassOpacity=60; var outlineEnabled=true; var outlineThickness=1.5f
    var bubbleEffect=true; var fontStyle="sans"
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private var phase=0f
    private var popupTitle:String?=null; private var popupBody:String?=null
    private val animator=ValueAnimator.ofFloat(0f,1f).apply{duration=1400;repeatCount=ValueAnimator.INFINITE;interpolator=LinearInterpolator();addUpdateListener{phase=it.animatedValue as Float;invalidate()}}
    init{animator.start()}
    fun showPopup(t:String,b:String){popupTitle=t;popupBody=b;invalidate()}
    fun clearPopup(){popupTitle=null;popupBody=null;invalidate()}
    fun hasPopup()=popupTitle!=null
    private fun accent():Int{val h=when(themeName){"mint"->155f;"blue"->215f;"rose"->340f;"custom"->customHue;else->270f};return Color.HSVToColor(floatArrayOf(h,.62f,1f))}
    override fun onDraw(c:Canvas){super.onDraw(c);val w=width.toFloat();val h=height.toFloat();if(w<=0||h<=0)return
        val a=accent();val r=RectF(w*.02f,h*.06f,w*.98f,h*.94f)
        p.style=Paint.Style.FILL;p.color=if(glassEnabled)Color.argb(glassOpacity.coerceIn(0,100)*255/100,42,48,66)else Color.rgb(3,5,12)
        if(bubbleEffect)p.setShadowLayer(if(expanded)22f else 14f,0f,4f,(a and 0xffffff)or(110 shl 24));c.drawRoundRect(r,h*.45f,h*.45f,p);p.clearShadowLayer()
        if(outlineEnabled){p.style=Paint.Style.STROKE;p.strokeWidth=outlineThickness.coerceIn(.5f,6f);p.color=(a and 0xffffff)or(150 shl 24);c.drawRoundRect(r,h*.45f,h*.45f,p)}
        p.style=Paint.Style.FILL
        val cy=if(expanded)h*.40f else h*.50f;val x1=if(expanded)w*.31f else w*.39f;val x2=if(expanded)w*.51f else w*.61f;val ew=h*.105f
        val blink=abs(sin(phase*Math.PI)).toFloat();val eyeH=when(expression){"sleep"->h*.018f;"happy"->h*.035f;"sad","angry"->h*.13f;else->h*(.055f+.075f*blink)}
        val eyeColor=when(expression){"happy"->0xff69f5be.toInt();"sad"->0xff78b9ff.toInt();"angry"->0xffff697d.toInt();"charging"->0xffffdc69.toInt();else->a}
        for(x in listOf(x1,x2)){p.color=eyeColor;val eye=RectF(x-ew,cy-eyeH,x+ew,cy+eyeH);c.drawRoundRect(eye,ew,ew,p)}
        if(musicActive){p.color=a;p.style=Paint.Style.STROKE;p.strokeWidth=(h*.055f).coerceAtLeast(2f);p.strokeCap=Paint.Cap.ROUND;val top=cy-h*.25f;val left=x1-ew*1.55f;val right=x2+ew*1.55f;c.drawArc(RectF(left,top,right,cy+h*.23f),190f,160f,false,p);p.style=Paint.Style.FILL;val cw=h*.10f;val ch=h*.25f;c.drawRoundRect(RectF(left-cw*.25f,cy-ch*.5f,left+cw*.55f,cy+ch*.5f),cw*.3f,cw*.3f,p);c.drawRoundRect(RectF(right-cw*.55f,cy-ch*.5f,right+cw*.25f,cy+ch*.5f),cw*.3f,cw*.3f,p)}
        p.color=Color.WHITE;p.typeface=Typeface.create(if(fontStyle=="serif")"serif"else if(fontStyle=="mono")"monospace"else"sans-serif-medium",Typeface.BOLD)
        if(popupTitle!=null){p.textSize=h*.14f;c.drawText(popupTitle!!.take(22),w*.65f,h*.37f,p);p.textSize=h*.10f;p.typeface=Typeface.DEFAULT;c.drawText((popupBody?:"").take(32),w*.65f,h*.55f,p)}else if(expanded){p.textSize=h*.12f;c.drawText(when(expression){"music"->"MUSIC PLAYING";"charging"->"CHARGING";"happy"->"HAPPY";"sad"->"SAD";"angry"->"ALERT";else->"ZENISLAND"},w*.66f,h*.48f,p)}
        if(expression=="music"||expression=="charging"){p.style=Paint.Style.STROKE;p.strokeWidth=3f;p.strokeCap=Paint.Cap.ROUND;p.color=if(expression=="charging")0xffffdc69.toInt()else a;for(i in 0..2){val x=w*(.79f+i*.045f);val amp=h*(.09f+.13f*abs(sin(phase*6f+i)).toFloat());c.drawLine(x,cy-amp,x,cy+amp,p)}}
    }
    override fun onDetachedFromWindow(){animator.cancel();super.onDetachedFromWindow()}
}
