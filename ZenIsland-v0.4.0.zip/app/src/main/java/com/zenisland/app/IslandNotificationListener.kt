package com.zenisland.app

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName == packageName) return
        val e=sbn.notification.extras
        val title=e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.take(70)?:sbn.packageName
        val body=(e.getCharSequence(Notification.EXTRA_BIG_TEXT)?:e.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.take(140)?:"New notification"
        sendBroadcast(Intent(IslandService.ACTION_NOTICE).setPackage(packageName).putExtra("title",title).putExtra("body",body))
        try { IslandService.wake(this) } catch (_:Exception) {}
    }
}
